@echo off
setlocal
cd /d "%~dp0"

py -3 -m PyInstaller --version >nul 2>nul
if errorlevel 1 (
  echo [ERROR] PyInstaller is not installed in the selected Python environment.
  echo Prepare it first, then run this script again. This script does not download packages.
  pause
  exit /b 1
)

py -3 -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --console ^
  --name Jammers-Offline ^
  --distpath release ^
  --workpath build-pyinstaller ^
  --specpath build-pyinstaller ^
  --add-data "dist;dist" ^
  start.py

if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)

echo [OK] release\Jammers-Offline.exe was created.
pause
endlocal
