# Jammers 离线模拟器 Windows 版 1.2.0

本包与 Linux `b-test` 版使用同一套仿真核心，新增 Windows 双击启动和 EXE 构建入口。它是独立重建的离线模拟器，不是对原版 EXE 的授权绕过版本。

## 直接运行

1. 安装 Python 3.10 或更高版本。
2. 解压完整 ZIP，不要只复制单个脚本。
3. 双击 `start_windows.bat`。
4. 浏览器会打开 `http://127.0.0.1:2027`；机器人接口为 `http://127.0.0.1:2026`。

运行数据写入本目录的 `runs` 文件夹。关闭命令行窗口即可停止服务。

## 构建 EXE

在已经准备好 Python 与 PyInstaller 的 Windows 电脑上双击 `build_windows.bat`。成功后生成：

`release\Jammers-Offline.exe`

随后再次双击 `start_windows.bat`，脚本会优先启动该 EXE。本构建脚本不会联网下载或自动安装依赖。

## 与 v1.0 相比

- 使用 v1.2.0 核心与 `practice-gen-v1` 场景生成器；
- 区分本地演练与本地正式流程；
- 支持本地正式次数、历史记录和场景包；
- 支持访问令牌、场景导入导出、CLI 和 Python 客户端；
- 保留 `/enter`、`/measure`、`/clear`、`/exit` 机器人接口；
- 保留 Docker、systemd 和 Linux 部署文件，便于同一份代码跨平台使用。

正式比赛服务端的场景生成算法没有还原。本包中的“正式”模式只是本地流程模拟，仍使用演练生成器，不连接官方服务，也不会消耗官方测试机会。

更完整的接口、命令行和部署说明见 `README.md` 与 `docs/API.md`。
