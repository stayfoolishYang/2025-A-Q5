@echo off
setlocal
cd /d "%~dp0"

if exist "release\Jammers-Offline.exe" (
  "release\Jammers-Offline.exe" --data-dir "%~dp0runs" --open-browser
  goto :end
)

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 start.py --data-dir "%~dp0runs" --open-browser
  goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
  python start.py --data-dir "%~dp0runs" --open-browser
  goto :end
)

echo [ERROR] Python 3.10+ was not found, and release\Jammers-Offline.exe does not exist.
echo Install Python 3.10+ or run build_windows.bat on a prepared Windows machine.
pause

:end
endlocal
