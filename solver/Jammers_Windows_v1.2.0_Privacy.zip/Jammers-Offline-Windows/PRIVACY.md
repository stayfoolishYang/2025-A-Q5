# Sharing copy

This copy removes historical test-environment fingerprints and precise timestamps,
PNG text/time metadata, and original ZIP timestamps/extra fields. Runtime logs,
credentials, caches and version-control metadata are excluded. Simulation code and
authentication behavior are unchanged. The 56 source tests passed on Linux;
Windows and a precompiled EXE have not been verified. This is a Python source package.

No configured personal account or actual access token was found in the inspected
package. Public branding and synthetic test seeds/tokens remain. This is not a
guarantee of anonymity: source content can still link releases. New runs can record
robot IDs, times, actions and local paths. Review runs and exports before sharing;
do not use personal information as a robot ID or seed.
