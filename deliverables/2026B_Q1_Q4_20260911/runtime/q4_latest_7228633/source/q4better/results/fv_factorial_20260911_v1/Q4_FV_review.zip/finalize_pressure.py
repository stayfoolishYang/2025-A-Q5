"""Audit supplemental new geometries and combine only the predeclared fresh-pressure subset."""
import json,gzip,hashlib,sys,zipfile,csv
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE));import fv_benchmark as b
from reporting.discovery_report import quantiles,write_csv
from reporting.nccp_report import audit_events
from reception_certificate import prepare
out=Path(__file__).resolve().parent;sup=out/'fresh_pressure_supplement'
def read(p):return json.load(gzip.open(p,'rt',encoding='utf-8')) if str(p).endswith('.gz') else json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=read(out/'manifest.json');sm=read(sup/'manifest.json');freeze=read(sup/'FREEZE.json')
assert freeze['manifest_sha256']==sha(sup/'manifest.json') and sm['source_hashes']==m['source_hashes']
assert b.fingerprints(Path(m['simulator_root']))==m['source_hashes']
ind=read(out/'GEOMETRY_INDEPENDENCE.json');novel={r['id'] for r in ind['all_current_records'] if r['cohort']=='stress' and r['novel_source_geometry_vs_accessible_history']}
assert len(novel)==12
rows=[];audit=[];states=[];actions=sets=certs=vchecks=0
for root,records in ((out,[r for r in m['records'] if r['id'] in novel]),(sup,sm['records'])):
 for rec in records:
  for v in b.VARIANTS:
   tag=f'{v}_{rec["id"]:04d}';row=read(root/f'core/rows/{tag}.json');trace=read(root/f'core/traces/{tag}.json.gz');fail=[]
   assert row==trace['row'] and row['scene_hash']==rec['scene_hash'] and row['source_hash']==b.rb.digest(m['source_hashes'])
   assert row['config_hash']==b.rb.digest(next(c for c in m['configs'] if c['name']==v))
   a=audit_events(trace,row,'mec_center');fail.extend(f for f in a['failures'] if not f.startswith('row:'))
   if root==sup:actions+=len(trace['actions']);sets+=row['conservative_set_checks'];certs+=a['certified_action_count']
   for target in trace['targets']:
    history=[a for a in trace['actions'] if a['path']=='/measure' and a['channel']==target['channel'] and a['response'].get('accepted') is True]
    for e in target.get('reception_events',[]):
     if root==sup:vchecks+=1
     if not prepare(e['polygon'],e['positives']).certify(e['point']) or e.get('response',{}).get('measure_result') not in ('direction','near'):fail.append('reception certificate failed')
     pp=[a['position'] for a in history if a['response'].get('measure_result') in ('direction','near') and a['response']['virtual_time_s']<=e['time_before']]
     if pp!=e['positives']:fail.append('positive history mismatch')
    one=nearline=0
    for e in target.get('reception_generations',[]):
     pp=np.asarray([a['position'] for a in history if a['response'].get('measure_result') in ('direction','near') and a['response']['virtual_time_s']<=e['time']],dtype=float)
     one+=len(pp)==1
     if len(pp)>=3:
      sig=np.linalg.svd(pp-pp.mean(axis=0),compute_uv=False);nearline+=sig[0]>.1 and sig[-1]<=.001
    states.append(dict(origin='supplement' if root==sup else 'original_novel',id=rec['id'],variant=v,family=rec['family'],channel=target['channel'],one_positive_states=one,near_collinear_states=int(nearline),discovery_no_signal=target.get('no_signal_by_purpose',{}).get('discovery',0)))
    for e in target.get('recovery_triggers',[]):
     old=loc=n=0;started=False
     for a in history:
      r=a['response']
      if r['virtual_time_s']>e['time']:continue
      if r['measure_result'] in ('direction','near'):old=loc=0;started=True;n+=int(r['measure_result']=='direction')
      elif started:old+=1;loc+=int(a['stage'] in ('active_localization','diagnostic'))
     if (old,loc,n)!=(e['total_consecutive_negatives'],e['local_negatives'],e['direction_count']):fail.append('local counter mismatch')
     if (loc if v in ('SF','SFV') else old)<3 and n<8:fail.append('recovery threshold failed')
   passed=not fail and row['run_status']=='FULL_CLEAR' and row['audit_passed']
   audit.append(dict(origin=str(root),id=rec['id'],variant=v,passed=passed,failures=fail))
   rows.append(dict(row,id=rec['id']+(326 if root==sup else 0),raw_id=rec['id'],origin='supplement' if root==sup else 'original_novel',cohort='fresh_pressure'))
assert len(rows)==128
summary={};comparisons={};pairs=[];inter=[]
for v in b.VARIANTS:
 g=[r for r in rows if r['variant']==v];summary[v]=dict(full=sum(r['run_status']=='FULL_CLEAR' for r in g),runs=len(g),per_source=quantiles([r['mean_time_per_source'] for r in g if r['run_status']=='FULL_CLEAR' and r['audit_passed']]),runtime=quantiles([r['runtime_s'] for r in g]))
for i in sorted({r['id'] for r in rows}):
 g={r['variant']:r for r in rows if r['id']==i};valid=all(r['run_status']=='FULL_CLEAR' and r['audit_passed'] for r in g.values())
 for base,opt in b.PAIRS:
  d=g[opt]['mean_time_per_source']-g[base]['mean_time_per_source'];pairs.append(dict(id=i,family=g[base]['family'],comparison=opt+'-'+base,delta_s_per_source=d,baseline=g[base]['mean_time_per_source'],delta_total_s=g[opt]['virtual_time_s']-g[base]['virtual_time_s'],valid=valid))
 inter.append(dict(id=i,interaction_s_per_source=g['SFV']['mean_time_per_source']-g['SF']['mean_time_per_source']-g['SV']['mean_time_per_source']+g['S0']['mean_time_per_source']))
for base,opt in b.PAIRS:
 p=[r for r in pairs if r['comparison']==opt+'-'+base and r['valid']];d=[r['delta_s_per_source'] for r in p]
 comparisons[opt+'-'+base]=dict(mean=float(np.mean(d)),percent=100*float(np.mean(d))/np.mean([r['baseline'] for r in p]),wins=sum(x< -1e-9 for x in d),ties=sum(abs(x)<=1e-9 for x in d),losses=sum(x>1e-9 for x in d),worst=max(p,key=lambda r:r['delta_s_per_source']))
state_summary=[]
for family in sorted({r['family'] for r in rows}):
 g=[r for r in states if r['family']==family];state_summary.append(dict(family=family,one_positive_states=sum(r['one_positive_states'] for r in g),near_collinear_positive_states=sum(r['near_collinear_states'] for r in g),discovery_no_signal=sum(r['discovery_no_signal'] for r in g)))
result=dict(passed=all(r['passed'] for r in audit),summary=summary,comparisons=comparisons,interaction=quantiles([r['interaction_s_per_source'] for r in inter]),original_novel_ids=sorted(novel),supplemental_records=20,source_geometry_novelty_verified=32,state_coverage=state_summary,supplement_audit_counts=dict(actions=actions,conservative_sets=sets,clear_certificates=certs,reception_certificates=vchecks))
b.rb.save(out/'fresh_pressure_summary.json',result);b.rb.save(out/'SUPPLEMENT_AUDIT.json',dict(passed=result['passed'],checks=audit))
for name,data in [('fresh_pressure_cases',rows),('fresh_pressure_pairs',pairs),('fresh_pressure_interaction',inter),('fresh_pressure_states',states),('fresh_pressure_state_summary',state_summary)]:write_csv(out/f'{name}.csv',data)
all_rows=[]
for path in (out/'cases.csv',sup/'stress_cases.csv'):
 with path.open(encoding='utf-8-sig') as f:
  for row in csv.DictReader(f):
   if path.parent==sup:row['id']=str(int(row['id'])+326);row['cohort']='pressure_supplement'
   all_rows.append(row)
write_csv(out/'all_cases.csv',all_rows)
for kind in ('pairs','interaction'):
 records=[]
 for path in (out/f'{kind}.csv',sup/f'stress_{kind}.csv'):
  with path.open(encoding='utf-8-sig') as f:
   for row in csv.DictReader(f):
    if path.parent==sup:row['id']=str(int(row['id'])+326);row['cohort']='pressure_supplement'
    records.append(row)
 write_csv(out/f'all_{kind}.csv',records)
report=(out/'REPORT.md').read_text()
report=report.replace('物理场景326个，其中320个新场景。','原始清单326个含噪声场景，对应324种源几何；几何审计发现原压力集20种布局复用历史，原清单仅300种几何对历史为新。后续补测见文末。')
report=report.replace('总任务尝试1316次，复用场景不增加独立数。','原始清单阶段任务尝试1316次；加下述80次补测，最终1396次完整任务尝试。复用场景不增加独立数。')
report+='\n\n## 几何去重修正与真正新布局压力32例\n\n源几何去重排除噪声种子：检查729个历史文件，728可由原引擎解析，540种历史几何；唯一无法解析的是无关100源扩展。主评估256例与开发32例全部为新布局。原压力32例中12例新布局、20例历史布局的新噪声重复。原结果完整保留，未依据成绩删除。\n\n对这20个历史布局统一旋转17.123度，定向朝向同步旋转，使用固定新噪声种子；补测清单在补测前冻结，按几何重复身份选择，不按成绩选择，策略源码未改。补测是在主评估已开始后安排的新增压力验证，不伪称最初预注册。12个原新布局加20个补充新布局组成以下32例新压力表。旋转仅提供新坐标布局，仍与原家族结构相关，不等同独立同分布抽样。\n\n|组别|全清/计划|均值 s/源|P50|P95|P99|max|\n|---|---:|---:|---:|---:|---:|---:|\n'
for v,q in summary.items():report+=f'|{v}|{q["full"]}/{q["runs"]}|'+ '|'.join(f'{q["per_source"][k]:.6f}' for k in ('mean','P50','P95','P99','max'))+'|\n'
report+='\n|配对|均差 s/源|变化 %|胜/平/负|最大退步 s/源|\n|---|---:|---:|---:|---:|\n'
for comp,q in comparisons.items():report+=f'|{comp}|{q["mean"]:.6f}|{q["percent"]:.6f}|{q["wins"]}/{q["ties"]}/{q["losses"]}|{q["worst"]["delta_s_per_source"]:.6f}|\n'
report+='\n实际状态覆盖（V开启组的生成状态，近共线为事后SVD描述）：\n\n|家族|单正观测状态|至少3正点近共线状态|discovery无信号次数|\n|---|---:|---:|---:|\n'
for r in state_summary:report+=f'|{r["family"]}|{r["one_positive_states"]}|{r["near_collinear_positive_states"]}|{r["discovery_no_signal"]}|\n'
report+='\n近共线正历史若为0，表示此完整任务压力未命中该状态，只能引用单元数值测试；不宣称完整覆盖。\n\n最终核心运行1384次=原计划1304+补充压力80；再加4冒烟与8HTTP，共1396次完整任务尝试。核心共346个含噪声场景、344种不同源几何，其中320种对可访问历史为新（开发32、评估256、新压力32），24种历史几何作为回归或噪声重复保留。几何新颖不等于统计独立证明。561次成功守卫后单点、6次旧边界反例及12次准备正测量另计，未算完整任务。\n\n补充生成预检曾因噪声种子长度及调用工作目录报错，均在任何引擎动作前修复、0完整运行；保留preflight记录。原冻结结果与策略均未改。\n'
(out/'REPORT.md').write_text(report,encoding='utf-8')
d=read(out/'DELIVERY.json');adopt=read(out/'ADOPTION.json');d['prerequisites_passed']=bool(d['prerequisites_passed'] and result['passed']);adopt['prerequisites_passed']=d['prerequisites_passed']
if not d['prerequisites_passed']:adopt['recommendation']='S0';d['recommendation']='S0'
b.rb.save(out/'ADOPTION.json',adopt)
# Include all supplemental traces; only selected original traces as before, plus fresh-pressure worst cases.
selected=set(d['selected_ids'])|{q['worst']['id'] for q in comparisons.values() if q['worst']['id']<326}
package=out/'Q4_FV_review.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file() and p.suffix in ('.json','.csv','.md','.txt','.patch','.py') and not p.name.startswith('server') and p.name not in ('DELIVERY.json','finalize_run.txt','finalize_final.txt'):z.write(p,p.name)
 for n in ('baseline_source.zip','frozen_source.zip'):z.write(out/n,n)
 for n in ('RECEPTION_CERTIFICATE.md','COVERAGE25.md'):z.write(BASE/n,n)
 z.write(BASE/'experiments/report_fv.py','report_fv.py')
 for rec in m['records']:z.write(out/rec['file'],rec['file'])
 for i in sorted(selected):
  for v in b.VARIANTS:
   rel=f'core/traces/{v}_{i:04d}.json.gz';z.write(out/rel,rel)
 for p in sup.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
 for rel in ('http/comparison.json','http/ownership.json','smoke/baseline_replay.json'):z.write(out/rel,rel)
with zipfile.ZipFile(package) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
d.update(finalize_script_sha256=sha(Path(__file__)),report_file_sha256=sha(out/'REPORT.md'),zip_sha256=sha(package),bytes=package.stat().st_size,selected_ids=sorted(selected),selected_traces=len(selected)*4+80,total_core_runs=1384,total_full_tasks=1396,scenario_count_including_noise=346,unique_source_geometries=344,novel_source_geometries=320,fresh_pressure_passed=result['passed'])
b.rb.save(out/'DELIVERY.json',d);print(json.dumps(dict(passed=result['passed'],summary=summary,delivery=d),ensure_ascii=False))
