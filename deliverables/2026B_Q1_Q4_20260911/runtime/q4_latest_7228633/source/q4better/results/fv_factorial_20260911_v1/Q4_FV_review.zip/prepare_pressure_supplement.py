from pathlib import Path
import json,math,hashlib,sys
from dataclasses import asdict
sys.path.insert(0,'B_solver');import fv_benchmark as b
root=b.BASE/'results/fv_factorial_20260911_v1';out=root/'fresh_pressure_supplement';m=json.loads((root/'manifest.json').read_bytes());ind=json.loads((root/'GEOMETRY_INDEPENDENCE.json').read_bytes());sim=Path(m['simulator_root']);sys.path.insert(0,str(sim));from scenario_io import load_scenario
assert not (out/'manifest.json').exists()
def gh(raw):return b.rb.digest(sorted([asdict(j) for j in load_scenario(raw).jammers],key=lambda j:j['channel']))
used=set()
for path in (b.BASE/'results').glob('**/scenes/*.json'):
 try:used.add(gh(json.loads(path.read_bytes())))
 except (ValueError,KeyError,TypeError):pass
records=[];angle=math.radians(17.123)
for r in ind['all_current_records']:
 if r['cohort']!='stress' or r['novel_source_geometry_vs_accessible_history']:continue
 raw=json.loads((root/r['file']).read_bytes())
 for j in raw['jammers']:
  x,y=j['x'],j['y'];j['x']=x*math.cos(angle)-y*math.sin(angle);j['y']=x*math.sin(angle)+y*math.cos(angle)
  if j['kind']=='directional':j['direction_deg']=(j['direction_deg']+17.123)%360
 raw['noise_seed_hex']=hashlib.sha256(f'2026B-fv-fresh-pressure-fixed-rotation:{r["id"]}'.encode()).hexdigest()[:16]
 geometry=gh(raw);assert geometry not in used;used.add(geometry)
 i=len(records);file=f'scenes/{i:04d}.json';b.rb.save(out/file,raw)
 records.append(dict(id=i,cohort='stress',family=r['family'],original_pressure_id=r['id'],file=file,total=len(raw['jammers']),scene_hash=b.rb.digest(raw),physical_hash=b.physical_hash(raw),source_geometry_sha256=geometry))
assert len(records)==20 and b.fingerprints(sim)==m['source_hashes']
supp=dict(m,records=records,design='20 pressure supplements: fixed17.123degree rigid rotation of geometries reused from history; directional headings rotate equally; fresh fixed noise hash. Selection solely historical geometry match, never performance. Frozen after main evaluation started; no strategy change. Original32pressure retained. Combine12novel original+20supplement for32novel pressure.',parent_manifest_sha256=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),frozen_at=__import__('datetime').datetime.now().isoformat())
b.rb.save(out/'manifest.json',supp)
b.rb.save(out/'FREEZE.json',dict(manifest_sha256=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),source_hash=b.rb.digest(m['source_hashes']),geometry_matches_rejected=True,novel_geometry_count=20,full_runs_planned=80))
print('Frozen20new geometry pressure /80core runs')
