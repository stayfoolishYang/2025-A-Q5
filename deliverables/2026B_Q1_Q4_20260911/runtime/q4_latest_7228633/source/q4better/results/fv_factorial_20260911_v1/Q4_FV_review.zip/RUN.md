# 本轮实际命令与复现

项目目录：E:\数模\projects\CUMCM2026_B_Q4_OPT\B_solver。
Python使用 C:\Users\asus\AppData\Local\Programs\Python\Python311\python.exe。
完整核心实验内部固定 OMP_NUM_THREADS=OPENBLAS_NUM_THREADS=MKL_NUM_THREADS=1，各实例独立。

```powershell
$py='C:\Users\asus\AppData\Local\Programs\Python\Python311\python.exe'
$sim='D:\桌面\2026国赛\b模拟器\Jammers-Offline-Windows'
$out='results/fv_factorial_20260911_v1'
$env:PYTHONPATH=$sim
& $py -m unittest discover -s tests -v
& $py experiments/check_fv_engine.py --sim-root $sim --output "$out/engine_single_points.json"
& $py fv_benchmark.py --sim-root $sim --output $out --freeze
& $py fv_benchmark.py --sim-root $sim --output $out --cohort development --workers 6
& $py fv_benchmark.py --sim-root $sim --output $out --cohort evaluation --workers 6
& $py fv_benchmark.py --sim-root $sim --output $out --cohort regression --workers 2
& $py fv_benchmark.py --sim-root $sim --output $out --cohort stress --workers 2
& $py experiments/http_fv.py --sim-root $sim --output $out --server-pid 47656 --ids 6 12
& $py experiments/report_fv.py --output $out
```

引擎56项测试在指定模拟器目录运行 `python -m unittest discover -s tests -v`。
HTTP服务实际参数：`start.py --robot-port 32026 --control-port 32027 --data-dir <本轮输出>/service --countdown 0 --no-browser`。
服务PID 47656只适用于本次执行；新运行必须核对新PID及命令行/端口所有者，禁止复用旧PID盲发动作。

历史输出不可覆盖。复现应使用新目录，将冻结manifest.json/scenes复制过去并使用frozen_source.zip内对应源码；原始场景重放不用再次--freeze。若重新生成新实验，应预置BASELINE.json及baseline_source.zip；同一生成前缀会因本地历史去重产生不同场景，必须重新冻结。
--resume只跳过已有行，不删除或重跑失败记录。报告脚本是只读策略的后处理，SHA256记录在DELIVERY.json。

冻结前额外冒烟是旧案例50四组，脚本和结果保留smoke_run.py及smoke/；不计新评估。最初边界反例保留，禁止用引擎改动消除它。新评估开始后未改策略或采样规则。

补充压力：在项目根目录执行 `python B_solver/results/fv_factorial_20260911_v1/prepare_pressure_supplement.py`；该生成器先核验全部历史几何哈希，固定17.123度旋转，写入独立子目录manifest/FREEZE。然后从B_solver目录执行：

```powershell
& $py fv_benchmark.py --sim-root $sim --output "$out/fresh_pressure_supplement" --cohort stress --workers 4
& $py experiments/report_fv.py --output $out
& $py "$out/finalize_pressure.py"
```

后处理顺序固定：先report_fv生成原清单报告，再finalize_pressure合并新压力报告及ZIP，避免重复追加。补测清单不可覆盖；复现新目录时应复制其冻结场景。all_cases/all_pairs/all_interaction包含原始与补测全部行，补测全局ID为326+子目录原始ID。
