"""Read-only F x V evidence audit and delivery; never changes frozen strategy."""
import argparse,csv,difflib,gzip,hashlib,json,sys,zipfile
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
import fv_benchmark as b
from reporting.discovery_report import quantiles,write_csv
from reporting.nccp_report import audit_events
from reception_certificate import prepare

def read(p):
    return json.load(gzip.open(p,'rt',encoding='utf-8')) if str(p).endswith('.gz') else json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=a.output.resolve()
    m=read(out/'manifest.json');sim=Path(m['simulator_root']);sys.path.insert(0,str(sim))
    assert b.fingerprints(sim)==m['source_hashes']
    with zipfile.ZipFile(out/'frozen_source.zip') as z:
        assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in m['source_hashes'].items())
        assert z.read('manifest.json')==(out/'manifest.json').read_bytes()
    assert sha(out/'baseline_source.zip')==m['baseline']['archive_sha256']
    summaries={c:read(out/f'{c}_summary.json') for c in ('regression','development','evaluation','stress')}
    http=read(out/'http/comparison.json');http_ok=len(http)==8 and all(all(r[k] for k in ('core_http_physical_rng_equal','full','audit_passed')) for r in http)
    rows=[];audit=[];replays=[];recovery=[];pressure=[];sets=actions=certs=vchecks=0
    prior=BASE/'results/known16_tri25_factorial_20260911_v1'
    for rec in m['records']:
        for v in b.VARIANTS:
            tag=f'{v}_{rec["id"]:04d}';row=read(out/f'core/rows/{tag}.json');t=read(out/f'core/traces/{tag}.json.gz')
            assert row==t['row'] and row['scene_hash']==rec['scene_hash'] and row['source_hash']==b.rb.digest(m['source_hashes'])
            assert row['config_hash']==b.rb.digest(next(c for c in m['configs'] if c['name']==v))
            ac=audit_events(t,row,'mec_center');fail=[f for f in ac['failures'] if not f.startswith('row:')]
            actions+=len(t['actions']);sets+=row['conservative_set_checks'];certs+=ac['certified_action_count']
            for target in t['targets']:
                for event in target.get('reception_events',[]):
                    vchecks+=1
                    if not prepare(event['polygon'],event['positives']).certify(event['point']):fail.append('V exact dispatch guard failed')
                    if event.get('response',{}).get('measure_result') not in ('direction','near'):fail.append('V feedback failed')
                    # Positive-set provenance uses only accepted same-channel earlier measurements.
                    pos=[x['position'] for x in t['actions'] if x['path']=='/measure' and x['channel']==target['channel'] and x['response'].get('accepted') is True and x['response'].get('measure_result') in ('direction','near') and x['response']['virtual_time_s']<=event['time_before']]
                    if pos!=event['positives']:fail.append('V positive history mismatch')
                for event in target.get('recovery_triggers',[]):
                    oldneg=localneg=ndirection=0;started=False
                    for action in t['actions']:
                        response=action['response']
                        if action['path']!='/measure' or action['channel']!=target['channel'] or response.get('accepted') is not True or response['virtual_time_s']>event['time']:continue
                        result=response.get('measure_result')
                        if result in ('direction','near'):
                            oldneg=localneg=0;started=True;ndirection+=int(result=='direction')
                        elif result=='no_signal' and started:
                            oldneg+=1;localneg+=int(action['stage'] in ('active_localization','diagnostic'))
                    correct=(oldneg==event['total_consecutive_negatives'] and localneg==event['local_negatives'] and ndirection==event['direction_count'])
                    threshold=localneg if v in ('SF','SFV') else oldneg
                    if not correct or not (threshold>=3 or ndirection>=8):fail.append('F recovery state replay failed')
                    recovery.append(dict(id=rec['id'],variant=v,channel=target['channel'],independent_counter_check=correct,**event))
                if rec['cohort']=='stress':
                    hist=[x for x in t['actions'] if x['path']=='/measure' and x['channel']==target['channel'] and x['response'].get('accepted') is True]
                    positives=[x['position'] for x in hist if x['response'].get('measure_result') in ('direction','near')]
                    first=next((i for i,x in enumerate(hist) if x['response'].get('measure_result') in ('direction','near')),None)
                    nearline=0
                    for generation in target.get('reception_generations',[]):
                        pp=np.asarray([x['position'] for x in hist if x['response'].get('measure_result') in ('direction','near') and x['response']['virtual_time_s']<=generation['time']],dtype=float)
                        if len(pp)>=3:
                            centered=pp-pp.mean(axis=0);singular=np.linalg.svd(centered,compute_uv=False)
                            if singular[0]>0.1 and singular[-1]<=0.001:nearline+=1
                    pressure.append(dict(id=rec['id'],variant=v,family=rec['family'],channel=target['channel'],near_collinear_positive_states_svd_le_1mm=nearline,positive_count=len(positives),initial_no_signal_count=first,discovery_no_signal=target.get('no_signal_by_purpose',{}).get('discovery',0),one_positive_generation_states=sum(sum(x['response'].get('measure_result') in ('direction','near') and x['response']['virtual_time_s']<=g['time'] for x in hist)==1 for g in target.get('reception_generations',[]))))
            audit.append(dict(id=rec['id'],variant=v,passed=not fail,failures=fail));rows.append(row)
            if rec['cohort']=='regression' and v=='S0':
                old=read(prior/f'core/traces/R12_{rec["previous_id"]:04d}.json.gz');equal=b.canonical_actions(t)==b.canonical_actions(old)
                replays.append(dict(id=rec['id'],previous_id=rec['previous_id'],exact_actions_rng=equal,delta_total_s=row['virtual_time_s']-old['row']['virtual_time_s'],tie_warning=rec['previous_id']==311 and not equal))
    assert len(rows)==1304
    prereq=all(x['passed'] for x in summaries.values()) and http_ok and all(x['passed'] for x in audit) and read(out/'engine_single_points.json')['passed'] and all(r['exact_actions_rng'] for r in replays)
    b.rb.save(out/'FORENSIC_AUDIT.json',dict(passed=prereq,actions=actions,conservative_set_checks=sets,clear_certificates=certs,reception_certificates=vchecks,checks=audit,baseline_replays=replays))
    write_csv(out/'cases.csv',rows);write_csv(out/'recovery_triggers.csv',recovery);write_csv(out/'pressure_observed_states.csv',pressure)
    pairs=[];interaction=[];worst=[];strata=[]
    for c in summaries:
        for name,destination in [('pairs',pairs),('interaction',interaction)]:
            with (out/f'{c}_{name}.csv').open(encoding='utf-8-sig') as f:destination.extend(csv.DictReader(f))
        for base,opt in b.PAIRS:
            q=[r for r in pairs if r['cohort']==c and r['comparison']==opt+'-'+base]
            worst.append(max(q,key=lambda r:float(r['delta_s_per_source'])))
        for label in ('all','10-15','16'):
            for v in b.VARIANTS:
                g=[r for r in rows if r['cohort']==c and r['variant']==v and (label=='all' or (r['total']==16)==(label=='16')) and r['run_status']=='FULL_CLEAR' and r['audit_passed']]
                strata.append(dict(cohort=c,stratum=label,variant=v,**quantiles([r['mean_time_per_source'] for r in g])))
    for name,data in [('pairs',pairs),('interaction',interaction),('strata',strata),('worst_cases',worst)]:write_csv(out/f'{name}.csv',data)
    worst_detail=[]
    for w in worst:
        i=int(w['id']);opt,base=w['comparison'].split('-');g={r['variant']:r for r in rows if r['id']==i}
        detail=dict(w)
        for k in ('distance','detect_count','failed_clears','diagnostic_count','stage_discovery_s','stage_active_localization_s','stage_diagnostic_s','stage_optical_fallback_s','stage_certified_clear_s','v_dispatched'):
            detail['delta_'+k]=g[opt][k]-g[base][k]
        target_rows=[]
        for v in (base,opt):
            trace=read(out/f'core/traces/{v}_{i:04d}.json.gz')
            target_rows.append({t['channel']:t for t in trace['targets']})
        ch=max(target_rows[0],key=lambda c:target_rows[1][c]['optical_clear_attempts']-target_rows[0][c]['optical_clear_attempts'])
        detail.update(largest_extra_optical_channel=ch,extra_optical_attempts=target_rows[1][ch]['optical_clear_attempts']-target_rows[0][ch]['optical_clear_attempts'])
        worst_detail.append(detail)
    write_csv(out/'worst_case_attribution.csv',worst_detail)
    ev=summaries['evaluation']['summary'];ref=ev['S0']['per_source'];adopt={}
    for v in ('SF','SV','SFV'):
        q=ev[v]['per_source'];mean=q['mean']<=.99*ref['mean'];tail=all(q[k]<=ref[k] for k in ('P95','P99'))
        adopt[v]=dict(eligible=prereq and mean and tail,mean_at_least_1pct=mean,P95_P99_nonincrease=tail,improvement_percent=100*(ref['mean']-q['mean'])/ref['mean'])
    best_single=min(('SF','SV'),key=lambda v:ev[v]['per_source']['mean']);margin=100*(ev[best_single]['per_source']['mean']-ev['SFV']['per_source']['mean'])/ev[best_single]['per_source']['mean']
    eligible=['S0']+[v for v in adopt if adopt[v]['eligible']];recommend=min(eligible,key=lambda v:ev[v]['per_source']['mean'])
    decision=dict(prerequisites_passed=prereq,adoption=adopt,best_measured_single=best_single,joint_marginal_percent=margin,joint_gain_limited=margin<1,recommendation=recommend)
    b.rb.save(out/'ADOPTION.json',decision)
    lines=['# Q4 F × V 四组冻结离线实验','',f'按预先门槛推荐：**{recommend}**。默认入口未替换，未推送远端。','',
    'S0=上一轮R12；SF=隔离局部失败计数；SV=增加经过严格认证和1微米内部余量检查的接收候选；SFV=同时开启。源数N仅用于事后T/N评价。以下均为指定离线引擎的实测虚拟时间。']
    for c,title in [('evaluation','新评估256例'),('stress','单列压力32例'),('development','新开发32例'),('regression','已知回归6例')]:
        lines+=['',f'## {title}','','|组别|全清/计划|均值 s/源|P50|P95|P99|max|平均整局 s|平均现实 s|','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
        for v,s in summaries[c]['summary'].items():
            q=s['per_source'];lines.append(f'|{v}|{s["full"]}/{s["runs"]}|'+ '|'.join(f'{q[k]:.6f}' for k in ('mean','P50','P95','P99','max'))+f'|{s["metrics"]["virtual_time_s"]["mean"]:.6f}|{s["metrics"]["runtime_s"]["mean"]:.6f}|')
        lines+=['','|配对（后−前）|均差 s/源|变化 %|胜/平/负|最大退步 s/源（案例）|','|---|---:|---:|---:|---:|']
        for comp,p in summaries[c]['comparisons'].items():
            s=p['all'];w=s['worst'];lines.append(f'|{comp}|{s["delta"]["mean"]:.6f}|{s["percent"]:.6f}|{s["wins"]}/{s["ties"]}/{s["losses"]}|{w["delta_s_per_source"]:.6f} ({w["id"]})|')
        lines+=['','交互项 I=SFV−SF−SV+S0：'+json.dumps(summaries[c]['interaction'],ensure_ascii=False),'','源数分层：'+json.dumps(summaries[c]['strata'])]
    lines+=['','## 主评估归因','','|组别|发现无信号|主动无信号|诊断无信号|V实际发出|V无信号|V构造现实秒|V额外诊断评分秒|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for v in b.VARIANTS:
        met=ev[v]['metrics'];lines.append('|'+v+'|'+'|'.join(f'{met[k]["mean"]:.6f}' for k in ('no_signal_discovery','no_signal_active','no_signal_diagnostic','v_dispatched','v_no_signal','v_generation_s','v_extra_scoring_s'))+'|')
    lines+=['','|组别|发现秒|主动定位秒|诊断秒|光学兜底秒|证书清除秒|移动米|检测次数|失败clear|','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for v in b.VARIANTS:
        met=ev[v]['metrics'];lines.append('|'+v+'|'+'|'.join(f'{met[k]["mean"]:.6f}' for k in ('stage_discovery_s','stage_active_localization_s','stage_diagnostic_s','stage_optical_fallback_s','stage_certified_clear_s','distance','detect_count','failed_clears'))+'|')
    lines+=['','## 主评估最大退步的费用归因','','|配对|案例|整局增时 s|多走 m|检测变化|光学兜底增时 s|最多额外光学尝试（频道）|','|---|---:|---:|---:|---:|---:|---:|']
    for w in worst_detail:
        if w['cohort']=='evaluation':lines.append(f'|{w["comparison"]}|{w["id"]}|{float(w["delta_total_s"]):.6f}|{w["delta_distance"]:.3f}|{w["delta_detect_count"]}|{w["delta_stage_optical_fallback_s"]:.6f}|{w["extra_optical_attempts"]} ({w["largest_extra_optical_channel"]})|')
    lines+=['','## 固定门槛与解释','',json.dumps(decision,ensure_ascii=False,indent=2),'',
    '三个候选均需正确性通过、无新增失败，主评估均值至少降低1%，P95/P99均不增加。F平均不足1%只可作为尾部候选；联合相对实测最佳单项的边际不足1%标为有限。I<0表示超出两个单项节省之和，I>0表示收益重叠或相互干扰。不能将两个百分比相加。配对变化百分比为100×配对均差/基线均值，不是逐例百分比的平均；分位数采用NumPy默认线性插值，256例P99仅受最高约3个观测主导，不能当总体尾部保证。所有失败保留；统计摘要中的时间只对全清有效行计算，存在失败则整体采用门槛失败，不把低耗时失败当胜利。',
    '各组10—15源与16源的均值/分位数见strata.csv，五个配对的分层胜平负与最大退步见evaluation_summary.json。完整整局时间、现实耗时、异常状态和阶段费用见cases.csv。压力家族名只描述预先构造几何，不保证策略必然经历该观测状态；实际单正观测及历史负观测情况见pressure_observed_states.csv。near_collinear_geometry构造的是源位置近共线，不等价于同频道正观测位置近共线；实际正历史至少3点且中心化SVD最小奇异值<=1毫米的状态计数另列CSV（仅事后描述性诊断，不是选点阈值），未命中的情形不称已覆盖。单元测试的近共线输入单独报告。minimum_radius与boundary_outward使用相同外缘最小半径构造、不同相位和噪声，不是孤立因素对照。',
    'V并不强制选证书点；其角域信息评分仍为启发式。与旧候选相距不足0.1米的新增候选被去重，旧候选继续用原评分，可能限制V收益；本轮未据评估结果调坐标、权重或此去重规则。V零无信号仅说明已发出证书点的接收表现，不能推出更短路径、更多信息或逐例提速。',
    '','## 正确性、运行计数与证据范围','',
    f'计划核心1304次=新开发128+新评估1024+压力128+已知回归24；物理场景326个，其中320个新场景。四组同场景独立初始化。另4次案例50冒烟和8次HTTP；总任务尝试1316次，复用场景不增加独立数。核心全清数{sum(r["run_status"]=="FULL_CLEAR" for r in rows)}；核心动作{actions}；保守集合包含性检查{sets}；清除证书{certs}；实际V证书复核{vchecks}。',
    '项目最终测试168项：161通过、7跳过；指定引擎56项通过。子代理几何24项及审查32项另有重复运行，不累加为不同测试。历史281状态的561个证书单点全部direction/near，不计作新完整任务。边界反例累计6次单点复现及12次准备正测量（子代理4、审查1、最终套件1），保留首次失败；这些不混入561次守卫后成功检测。',
    'S0基线回放核对：'+json.dumps(replays,ensure_ascii=False),
    '每动作使用原引擎微秒取整规则核对 T=L/5+5M+S+3F_clear+5K，clear不切频。所有真实源包含性只由评估器检查，真值未进入在线选点。完整V事件重新核对原始Ω、合法同频道正历史、精确内部余量和实际反馈。HTTP每次enter前核对指定目录服务PID；8次动作/物理反馈/RNG/虚拟时间对照见http/comparison.json。',
    '原理想圆盘/半圆盘的连续支撑函数证明成立；原引擎angular_distance<=90.000000001使接收区略不凸，原始无余量证书存在真实反例。当前仅发出半径1/1000000米闭圆盘严格包含于每个扩展凸包的点：不缩小Ω、不修改引擎，退化或过薄集合回退。固定余量覆盖显式角度容差；没有对厂商libm全部binary64输入做形式化正确性认证，不能声称无条件机器级全域保证。完整证明及限制见RECEPTION_CERTIFICATE.md。',
    '证据层级LOCAL_DEV / FRAMEWORK_INTEGRATION / production_eligible=false。场景是冻结生成与构造的离线场景，不代表官方分布保证；不更新生产Gate、current_best_verified或Model Freeze。',
    '','## 来源与回传','',f'上一轮R12实际基线包SHA256：{sha(out/"baseline_source.zip")}',f'本轮执行源指纹集合SHA256：{b.rb.digest(m["source_hashes"])}',f'原引擎：{sim}',f'engine.py SHA256：{m["source_hashes"]["engine/engine.py"]}',f'可访问历史物理哈希检查数：{m["historical_physical_hashes_checked"]}；仅覆盖本地可解析存档，未存档/不可访问历史无法完整排除。100源扩展不使用此原引擎，未混入本轮。',
    'BASELINE.json记录上一轮34个solver文件逐字节对应；baseline_source.zip保存原始执行版本。frozen_source.zip保存本轮源码、配置和清单。完整轨迹在core/traces；精简ZIP包含全部六个已知案例与每个cohort五项比较最大退步案例的四组轨迹，未只保留赢家。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    with zipfile.ZipFile(out/'baseline_source.zip') as z:
        diff=[]
        for name in z.namelist():
            rel=name.removeprefix('solver/');path=BASE/rel
            if path.is_file():diff.extend(difflib.unified_diff(z.read(name).decode().replace('\r\n','\n').splitlines(keepends=True),path.read_text().splitlines(keepends=True),fromfile='R12/'+rel,tofile='FV/'+rel))
        for rel in ('reception_certificate.py','RECEPTION_CERTIFICATE.md','tests/test_fv_integration.py','tests/test_reception_certificate.py','fv_benchmark.py','experiments/http_fv.py','experiments/check_fv_engine.py'):
            diff.extend(difflib.unified_diff([], (BASE/rel).read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='FV/'+rel))
        (out/'changes.patch').write_text(''.join(diff),encoding='utf-8')
    selected={int(r['id']) for r in worst}|{r['id'] for r in m['records'] if r['cohort']=='regression'}
    package=out/'Q4_FV_review.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for p in out.iterdir():
            if p.is_file() and p.suffix in ('.json','.csv','.md','.txt','.patch') and not p.name.startswith('server') and p.name!='DELIVERY.json':z.write(p,p.name)
        for name in ('baseline_source.zip','frozen_source.zip'):z.write(out/name,name)
        for name in ('RECEPTION_CERTIFICATE.md','COVERAGE25.md'):z.write(BASE/name,name)
        z.write(Path(__file__),'report_fv.py')
        for rec in m['records']:z.write(out/rec['file'],rec['file'])
        for i in sorted(selected):
            for v in b.VARIANTS:
                rel=f'core/traces/{v}_{i:04d}.json.gz';z.write(out/rel,rel)
        for rel in ('http/comparison.json','http/ownership.json','smoke/baseline_replay.json'):z.write(out/rel,rel)
    with zipfile.ZipFile(package) as z:assert z.testzip() is None
    b.rb.save(out/'DELIVERY.json',dict(zip_path=str(package),zip_sha256=sha(package),bytes=package.stat().st_size,selected_ids=sorted(selected),selected_traces=len(selected)*4,manifest_sha256=sha(out/'manifest.json'),report_sha256=sha(Path(__file__)),recommendation=recommend,prerequisites_passed=prereq))
    print(json.dumps(decision,ensure_ascii=False))
if __name__=='__main__':main()
