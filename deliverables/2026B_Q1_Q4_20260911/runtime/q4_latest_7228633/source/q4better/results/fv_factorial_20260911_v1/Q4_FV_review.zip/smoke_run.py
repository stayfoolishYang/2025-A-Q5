from pathlib import Path
import sys,json
sys.path.insert(0,'B_solver');import fv_benchmark as b
sim=Path(r'D:\桌面\2026国赛\b模拟器\Jammers-Offline-Windows');sys.path.insert(0,str(sim))
out=b.BASE/'results/fv_factorial_20260911_v1/smoke';prior=b.BASE/'results/known16_tri25_factorial_20260911_v1';m=json.loads((prior/'manifest.json').read_bytes());r=dict(m['records'][50]);r.update(id=0,cohort='smoke',file='scenes/0000.json');cfg=next(c for c in m['configs'] if c['name']=='R12')
b.rb.save(out/r['file'],json.loads((prior/m['records'][50]['file']).read_bytes()))
b.rb.save(out/'manifest.json',dict(records=[r],configs=[dict(cfg,name=v,isolate_local_failures=v in ('SF','SFV'),reception_certified_candidates=v in ('SV','SFV')) for v in b.VARIANTS],source_hashes=b.fingerprints(sim)))
for v in b.VARIANTS:
 r=b.run_case((out,sim,0,v,None));print(v,r['run_status'],r['audit_passed'],r['virtual_time_s'],r['v_dispatched'],flush=True)
with b.gzip.open(out/'core/traces/S0_0000.json.gz','rt',encoding='utf-8') as f:a=json.load(f)
with b.gzip.open(prior/'core/traces/R12_0050.json.gz','rt',encoding='utf-8') as f:c=json.load(f)
assert b.canonical_actions(a)==b.canonical_actions(c)
b.rb.save(out/'baseline_replay.json',dict(previous_id=50,exact_actions_rng=True,actions=len(a['actions'])))
