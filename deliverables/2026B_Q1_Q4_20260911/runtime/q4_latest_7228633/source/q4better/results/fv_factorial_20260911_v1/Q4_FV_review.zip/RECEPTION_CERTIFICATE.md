# Q4 V：连续接收证书、严格数值认证与引擎边界修正

本文件仅说明 V 的几何模块。候选的评分、用途计数、HTTP 协议、完整离线配对及采用判定由本轮主报告给出。几何单元测试通过不等于整局运行通过，也不等于 V 提速。

## 1. 集合与前提

- \(P\) 仅包含本频道、尚未清除时、`accepted=true` 且 `direction/near` 的真实历史测量位置。负观测、其他频道、clear 位置、规划假设反馈均不得直接进入 \(P\)。
- 原始数组的全部顶点记为 \(V_\Omega\)，解释为 \(\Omega=\operatorname{conv}(V_\Omega)\)，要求真实源 \(g\in\Omega\)。不得靠内缩 Ω 或近似删极点增加证书区域。
- 源、半径及朝向固定。证书不能修复错误的 Ω 或正观测来源，也不是 20 米清除证书。
- 空 \(P\) 不输出证书；空 Ω 不作空交集的真命题处理。

定义保持用户指定形式：

\[
R_{\rm cert}=\bigcap_{v\in V_\Omega}\operatorname{conv}(P\cup\{v\}).
\]

## 2. 独立复核的连续证明

先考虑理想闭圆盘，或理想闭圆盘与过 \(g\) 闭半平面的交集，记为 \(C_g\)。两者均为含 \(P\cup\{g\}\) 的紧凸集，所以

\[
\operatorname{conv}(P\cup\{g\})\subseteq C_g.
\]

任取 \(q\in R_{\rm cert}\) 和方向 \(n\in\mathbb R^2\)。令
\(h_P(n)=\max_{p\in P}n^Tp\)。由 q 属于每个扩展凸包，

\[
n^Tq\le\min_{v\in V_\Omega}\max(h_P(n),n^Tv)
=\max\!\left(h_P(n),\min_{v\in V_\Omega}n^Tv\right)
\le\max(h_P(n),n^Tg).
\]

中间等式成立是因为 \(t\mapsto\max(h_P(n),t)\) 单调且顶点集合有限；最后不等式来自 \(g\in\operatorname{conv}(V_\Omega)\)。右端恰是 \(\operatorname{conv}(P\cup\{g\})\) 的支撑函数。对所有方向均成立，由闭凸集的支撑半空间表示可得

\[
R_{\rm cert}\subseteq\operatorname{conv}(P\cup\{g\})\subseteq C_g.
\]

每个扩展凸包均包含 \(\operatorname{conv}(P)\)，故后者包含于 \(R_{\rm cert}\)。区域可以延伸到正观测凸包之外，也可能只有点或线段。证明没有有限采样替代连续包含性的步骤。

## 3. 实际引擎的不凸边界：首次失败必须保留

指定引擎 `D:\桌面\2026国赛\b模拟器\Jammers-Offline-Windows\engine.py` 第 199–202 行用

```python
covered = angular_distance <= 90.000000001
```

定向接收角宽略大于 180°，因此实际允许区域在边界上不严格凸。仅靠上一节的理想凸性证明及精确成员判据，不能无条件推出实际引擎必有信号。

已用该文件的真实 `Engine` 核心直接执行以下反例，未改引擎，未使用 `LocalSimulator`：

```json
{
  "format": "jammers-offline-v1",
  "noise_seed_hex": "0000000000000001",
  "problem": 4,
  "generator_seed": "V-angular-tolerance-counterexample",
  "jammers": [
    {"channel": 1, "x": 0.0, "y": 0.0,
     "receive_radius_m": 1000.0, "kind": "directional", "direction_deg": 0.0}
  ],
  "omega": [[-20.0,-20.0],[20.0,-20.0],[20.0,20.0],[-20.0,20.0]],
  "positives": [[-1e-9,100.0],[-1e-9,-100.0]],
  "ideal_certified_candidate": [-1e-9,0.0]
}
```

这里后面三个字段是证据说明，不属于 `Scenario.from_dict` 的场景字段；构造场景时只传前五个字段。该自定义单源场景是单点正确性测试，不计入主评估的 10–16 源完整任务。

| 请求 | accepted | 返回 | virtual_time_s |
| --- | --- | --- | ---: |
| `/enter` | true | 入场 | 0 |
| 测量 `(-1e-9,100)` | true | `direction`, `svd_deg=269.73` | 25 |
| 测量 `(-1e-9,-100)` | true | `direction`, `svd_deg=89.76` | 70 |
| 测量 `(-1e-9,0)` | true | **`no_signal`** | 95 |

两个正观测比理想边界向后约 \(5.73\times10^{-10}\) 度，均在引擎容差内。中点在正观测线段上，所以对全部四个 Ω 顶点逐一进行精确成员检查也必然通过；它距每个历史站位 100 米，重复点过滤不能消除反例。Ω 包含真实源且 MEC 半径约 28.28 米，例子没有用错误 Ω 或 20 米证书解释失败。中点方向为 180°，引擎先检查覆盖再检查 near，因此返回 no_signal。

原始无内点余量的 V 在此例为 **模型／引擎不一致**。以下修正保留这个失败；测试不删除反例，也不通过放宽成员容差掩盖它。

## 4. 固定保守发出条件：原区域内的 1 微米闭圆盘

修正只对候选发出增加保守条件：

\[
B(q,\delta)\subseteq R_{\rm cert},\qquad
\delta=\frac1{1\,000\,000}\ \mathrm m.
\]

δ 是预先固定的数值余量，不是从任务耗时或评估集搜索的策略参数。原 Ω、原 \(R_{\rm cert}\)、三个候选构造目标和评分权重均不变。该条件是原区域的子集检查，不会放大证书区域。点、线段、薄到不能容纳该圆盘的区域会放弃新增候选，恢复原策略。

说明该余量为何能处理角度容差：令 \(u\) 为真实朝向单位向量，\(\varepsilon=10^{-9}\) 度。暂按精确角度、精确距离解释引擎阈值，正观测必满足

\[
u^T(p-g)\ge-\eta,\qquad
\eta=1500\sin\varepsilon\approx2.617993878\times10^{-8}\ \mathrm m.
\]

因此正观测和 g 都处在同一放松闭半平面 H 内。由第二节支撑函数证明，\(B(q,\delta)\subseteq\operatorname{conv}(P\cup\{g\})\subseteq H\)。特别取 \(q-\delta u\)，得到

\[
u^T(q-g)\ge\delta-\eta>0.
\]

于是发出的 q 在理想前半平面内，且有严格正余量；它不依赖正观测各自在理想边界哪侧。对圆盘也有对应结论：若所有正观测的真实距离至多 \(R+e_r\)，上述凸包落在半径 \(R+e_r\) 的圆盘内；而整个 \(B(q,\delta)\) 都在此圆盘内，故

\[
\lVert q-g\rVert\le R+e_r-\delta.
\]

只要前后两次距离计算的总误差小于 δ，候选严格落在接收圆盘内。

数值适用边界必须明确：上述几何推导是证明；Python 所调用的厂商 `atan2`/`hypot` 实现未在本任务中完成对所有 binary64 输入的形式化误差认证。若采用远宽于普通 binary64 舍入的保守数值包络——角度求值误差不超过 \(10^{-10}\) 度、坐标／距离比较误差不超过 \(10^{-9}\) 米——角度和位置引起的最大后退仍小于 \(3.0\times10^{-8}\) 米，距 1 微米余量有超过 30 倍空间。实际引擎单点与完整轨迹验证仍须单独报告；不能把这些有限实验说成厂商 libm 的穷尽证明。任何实际发出点返回 no_signal 都必须保留完整证据并判该 V 运行不一致。

此修正会拒绝第 3 节的全部候选；`certify_ideal` 对中点仍为 true，`certify` 为 false，生成函数返回空候选并记录 `no_margin_certified_interior`。

## 5. 构造与认证实现

文件：`reception_certificate.py`，仅依赖标准库与项目现有 NumPy。

1. 读入有限 FP64 坐标副本，稳定排序并仅删除完全重复的 P。全部原 Ω 顶点保留在证据中；完全重复的 Ω 约束可以共享。
2. 用每个原顶点与 P 构造扩展凸包。拓扑的方向符号用 `Fraction(float)` 精确二进制有理数；只删除真正共线的非极点，不以正容差删除近共线极点。构造坐标保持原 FP64；凸包求交使用 FP64 半平面裁剪。
3. 点凸包表示为两个坐标等式；线段表示为共线等式及端点包围盒；面凸包用全部边的闭半平面。重复边只合并完全相同的整数约束，其逻辑仍等价于逐个检查所有原顶点扩展凸包。
4. 每条约束写为整数 \(A x+B y+C\ge0\)。坐标经过与客户端一致的 `float → JSON {x,y} → 解析` 往返，再将分母乘开为整数，精确判定其符号。没有正成员容差。
5. `certify_ideal(q)` 要求所有符号非负。用于实际发出的 `certify(q)` 还要求

\[
(Aq_x+Bq_y+C)^2\ge\delta^2(A^2+B^2),
\quad Aq_x+Bq_y+C\ge0.
\]

所有乘法、平方和比较均在 Python 整数上执行；等价于精确检查点距每条支撑线至少 δ。δ 用精确有理数 `1/1000000`，不会因 binary64 的 `1e-6` 略小而放松条件。

6. FP64 构造为空记录 `numerical_construction_empty`，不得解释为没有目标。构造顶点均值不满足发出条件且没有其他固定安全锚点时，不发出需要修复的候选。

## 6. 固定候选、收缩及不变性

每个状态固定尝试三个候选，顺序为：

1. 构造区域中最接近现有 MEC 中心的点；
2. 构造区域中最接近机器人当前位置的点；
3. 去重构造凸包顶点的稳定均值。

点和线段使用对应投影定义。实际发出可能因数值余量收缩，所以不宣称发出坐标仍为数学上精确最近点或连续全局最优点。若原策略已计算 MEC 中心，应通过 `mec_center=` 传入；未传入时只用确定性增量包围圆构造目标，不创建或推进 RNG。

优先用通过发出认证的区域均值作为锚点；其次尝试固定正观测均值和首个正点。构造候选不通过时，按固定

```text
2^-48, 2^-44, 2^-40, ..., 2^-4, 1
```

比例向锚点收缩，每次重新 JSON 往返并严格认证；仍不通过则丢弃。只有已通过发出认证的锚点才用于修复。首个正点在一般非退化集合边界上往往不能满足余量，因此不会被错误当成安全内点。

返回点按上述顺序，用项目原有 `<0.1 m` 判定检查本频道**全部历史检测站位**和已返回候选，最多三个，不用随机点凑数。真实发出前若旧重复点替换机制或其他逻辑改坐标，必须对最终坐标重新调用 `certify`；标签不能沿用。

`PreparedCertificate` 为冻结 dataclass，内部全部是不可变元组；LRU 仅缓存几何，最多 128 个状态。公开函数不修改历史、tracks、粒子、数组输入或随机状态。证据输出只包含坐标和认证信息，没有隐藏真值。

## 7. API 与归因字段

```python
prepared = prepare(poly, positives)
points, metadata = prepared.generate_candidates(
    current, history_points, mec_center=existing_mec_center)
assert all(prepared.certify(point) for point in points)
evidence = prepared.evidence(final_submitted_point)
```

便捷函数为 `generate_candidates(poly, positives, current, history_points, mec_center=None)`、`certify(point, poly, positives)`、`certify_ideal(point, poly, positives)`。其中 `mec_center` 是可选关键字参数。

元数据含 `generated/passed/rejected/shrunk/history_filtered/duplicate_filtered`、维数、构造状态、`dispatch_margin_m`、每个构造点及最终点、固定收缩比例、数值失败原因与现实计算时间。`passed` 是通过发出条件的尝试数，包含随后被重复点过滤的尝试，不等同于新增点数。原始 Ω/P 可由 `evidence` 重建全部精确约束。

## 8. 已执行检查与证据边界

命令（在 `B_solver` 中）：

```powershell
python -m unittest discover -s tests -p test_reception_certificate.py -v
```

当前版本 **24 项通过，0 跳过**；保存日志的最后一次执行用时约 0.33 秒，日志位于 `results/fv_factorial_20260911_v1/reception_tests.txt`。包含独立 Carathéodory 三点枚举有理数成员 oracle；空 P/Ω；点与线段；重复／逆序／近共线；极小面积和多次裁剪；一 ULP 越界；JSON 往返；固定收缩；精确 1 微米余量及相邻浮点；全部历史过滤；缓存和真实数组不变；禁止 RNG；改坐标重新认证；以及指定引擎原始边界失败与修正后不发出的回归。

该测试套件中的实际引擎测试**有意执行原始理想证书中点**，断言它返回 no_signal，以保存反例；同时断言修改后的生成器没有发出候选。这个通过项不能写成“该点保证接收通过”。修改后实际被发出的安全候选之 direction/near 检查由本轮主执行器另行报告。

本子任务先执行一次直接反例、一次 23 项旧版套件、两次 24 项修正版套件（第二次保存正式日志）：共 **4 次同一原始证书单点复现，8 次准备正观测**，不构成四个独立场景，也不构成完整任务。首次实际输入、全部响应、原引擎 SHA-256 及修正后拒绝结果保存在 `results/fv_factorial_20260911_v1/first_reception_counterexample.json`，其首次执行计数单独为 2 次准备加 1 次证书检测。主执行器若重跑套件，应继续累加单点次数并保持独立场景数不变。

纯几何开销抽查（128 个 Ω 顶点、4 个正点，非任务性能证据）：首次构造约 0.020 秒，缓存后 100 次生成均值约 0.00146 秒；209 个精确半平面，返回 2 点。这只说明现实计算开销，不能换算成虚拟任务时间收益。

尚须主执行器验证：实际策略发出的安全证书点反馈、无证书点原评分不变、证书点正确排除 no_signal 分支、空粒子／空分支诊断、默认和 Q3 回归、四组完整配对、HTTP 对照、源包含性、覆盖与清除义务，以及全部性能门槛。
