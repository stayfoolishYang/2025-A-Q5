from pathlib import Path
p=Path('B_solver')
s=(p/'known16_tri25_benchmark.py').read_text()
s=s.replace("('R0','R1','R2','R12')", "('S0','SF','SV','SFV')").replace("(('R0','R1'),('R0','R2'),('R0','R12'),('R1','R12'),('R2','R12'))", "(('S0','SF'),('S0','SV'),('S0','SFV'),('SF','SFV'),('SV','SFV'))")
s=s.replace("'COVERAGE25.md')", "'COVERAGE25.md','fv_benchmark.py','reception_certificate.py','RECEPTION_CERTIFICATE.md','tests/test_reception_certificate.py','tests/test_fv_integration.py','experiments/http_fv.py','experiments/check_fv_engine.py')")
s=s.replace("results/public_max37/frozen", "results/known16_tri25_factorial_20260911_v1")
s=s.replace("cfg=json.loads((BASE/'configs/q4_public_max37_C.yaml').read_bytes())", "cfg=next(c for c in pm['configs'] if c['name']=='R12')")
a=s.index('    configs=[dict(cfg');b=s.index('    records=[]',a)
s=s[:a]+'''    configs=[dict(cfg,name=v,isolate_local_failures=v in ('SF','SFV'),reception_certified_candidates=v in ('SV','SFV')) for v in VARIANTS]
    for c in configs: rb.save(BASE/f'configs/q4_fv_{c["name"]}.yaml',c)
'''+s[b:]
s=s.replace('(60,67,71,119,171)', '(50,218,253,288,298,311)').replace("family='previous_C'", "family='previous_R12'")
s=s.replace('2026B-known16-tri25-v1:', '2026B-fv-20260911-v1:').replace('2026B-known16-tri25-pressure-v1:', '2026B-fv-pressure-20260911-v1:')
s=s.replace("('boundary_outward','grid_vicinity','cluster_mixed','high_directional','all_omni','all_directional','generated_16','boundary_tangent')", "('boundary_outward','one_positive_geometry','cluster_mixed','many_discovery_negatives','minimum_radius','all_directional','generated_16','near_collinear_geometry')")
s=s.replace("family=='grid_vicinity'", "family=='one_positive_geometry'").replace("family=='high_directional'", "family=='many_discovery_negatives'").replace("family=='boundary_tangent'", "family=='near_collinear_geometry'")
s=s.replace("if family=='many_discovery_negatives': x,y=1300*math.cos(angle),1300*math.sin(angle)", "if family=='many_discovery_negatives': x,y=1300*math.cos(angle),1300*math.sin(angle)\n                if family=='near_collinear_geometry': x,y=-600+i*80,200+1e-7*i*i")
s=s.replace("adoption='State/continuous coverage and no new failures prerequisite. R1 evaluate N16, unchanged N<16. R2/R12 mean >=1% faster and P95/P99 nonincrease versus R0. Joint must beat best single; marginal<1% limited. Pressure separate.'", "adoption='All correctness gates and no new failures. Each SF/SV/SFV mean >=1% faster and P95/P99 nonincrease versus S0. F below1% tail candidate only. Joint vs best single marginal<1% limited. Pressure separate; pressure family labels describe geometry, observed states audited separately.'")
s=s.replace('Frozen 325 scenes / 1300 core runs','Frozen 326 scenes / 1304 core runs')
s=s.replace("known16_enabled=v in ('R1','R12')", "known16_enabled=True")
a=s.index('        exact=[]');b=s.index('        full=all(',a)
s=s[:a]+s[b:]
s=s.replace("prefix_equal=all(exact),all_full=full,passed=all(exact) and full", "all_full=full,passed=full")
for a,b in [('R12','SFV'),('R0','S0'),('R1','SF'),('R2','SV')]:
    # Only remaining report interaction group references.
    s=s.replace("group['"+a+"']", "group['"+b+"']")
a=s.index("    trace['known16_evidence']=trigger")
s=s[:a]+'''    for purpose in ('discovery','active','diagnostic'):
        row['no_signal_'+purpose]=sum(t.get('no_signal_by_purpose',{}).get(purpose,0) for t in trace['targets'])
    generations=[g for t in trace['targets'] for g in t.get('reception_generations',[])]
    events=[g for t in trace['targets'] for g in t.get('reception_events',[])]
    for key in ('generated','passed','degenerate','rejected','shrunk','history_filtered'):
        row['v_'+key]=sum(g.get(key,0) for g in generations)
    row['v_generation_s']=sum(g.get('elapsed_s',0) for g in generations)
    row['v_extra_scoring_s']=sum((g.get('plan') or {}).get('extra_scoring_s',0) for t in trace['targets'] for g in t.get('diagnostic_decisions',[]))
    row['v_dispatched']=len(events)
    row['v_no_signal']=sum(g.get('response',{}).get('measure_result')=='no_signal' for g in events)
    row['v_direction']=sum(g.get('response',{}).get('measure_result')=='direction' for g in events)
    row['v_near']=sum(g.get('response',{}).get('measure_result')=='near' for g in events)
    row['recovery_triggers']=sum(len(t.get('recovery_triggers',[])) for t in trace['targets'])
    if 'certificate/model inconsistency' in row['error']:
        row['run_status']='CERTIFICATE_MODEL_INCONSISTENCY';row['audit_passed']=False
'''+s[a:]
s=s.replace("metrics=('virtual_time_s'", "metrics=('no_signal_discovery','no_signal_active','no_signal_diagnostic','v_generated','v_passed','v_degenerate','v_dispatched','v_no_signal','v_direction','v_near','v_generation_s','v_extra_scoring_s','recovery_triggers','virtual_time_s'")
(p/'fv_benchmark.py').write_text(s)
h=(p/'experiments/http_known16_tri25.py').read_text().replace('import known16_tri25_benchmark as bench','import fv_benchmark as bench')
(p/'experiments/http_fv.py').write_text(h)
