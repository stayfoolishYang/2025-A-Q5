"""Read frozen results, write the requested concise report and review bundle."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile
import numpy as np

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE));import public_max37_benchmark as bench


def main():
    root=BASE/'results/public_max37';out=root/'frozen';m=json.loads((out/'manifest.json').read_bytes())
    assert bench.fingerprints(Path(m['simulator_root']))==m['source_hashes']
    rows=[json.loads(p.read_bytes()) for p in sorted((out/'core/rows').glob('*.json'))]
    assert len(rows)==540 and all(r['run_status']=='FULL_CLEAR' and r['audit_passed'] for r in rows)
    for rec in m['records']:
        assert bench.rb.digest(json.loads((out/rec['file']).read_bytes()))==rec['scene_hash']
    summaries={c:json.loads((out/f'{c}_summary.json').read_bytes()) for c in ('development','evaluation','stress')}
    http=json.loads((out/'http/comparison.json').read_bytes())
    assert len(http)==6 and all(x['core_http_physical_rng_equal'] and x['full'] and x['audit_passed'] for x in http)
    e=summaries['evaluation'];g=[r for r in rows if r['cohort']=='evaluation']
    by={(r['id'],r['variant']):r for r in rows}
    pairs=[]
    for rec in m['records']:
        for a,b in (('A','B'),('B','C'),('A','C')):
            x,y=by[rec['id'],a],by[rec['id'],b]
            pairs.append(dict(id=rec['id'],cohort=rec['cohort'],family=rec['family'],N=rec['total'],
                comparison=b+'-'+a,delta_s_per_source=y['mean_time_per_source']-x['mean_time_per_source'],
                delta_total_s=y['virtual_time_s']-x['virtual_time_s'],delta_movement_s=(y['distance']-x['distance'])/5,
                delta_detection_s=5*(y['detect_count']-x['detect_count']),delta_switch_s=y['switch_count']-x['switch_count'],
                delta_failed_clear_s=3*(y['failed_clears']-x['failed_clears']),
                directional_count=x['directional_count'],strict_mixed=0<x['directional_count']<x['total']))
    for name,data in (('cases.csv',rows),('pairs.csv',pairs)):
        with (root/name).open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=sorted(set().union(*(r.keys() for r in data))));w.writeheader();w.writerows(data)
    lines=['# Q4：16源退出与37点覆盖优化验证','',
        '**结论：B 通过；C 在冻结新评估集达到采用门槛，建议保留 B+C 为显式候选配置。原默认入口未替换。**',
        'C 不具备整局逐例不劣保证：新评估有 4 例比 B 慢，单列压力集 P95 上升。若要求逐例不增加耗时，只有 B 具备本轮证明与配对验证支持。','',
        '## 基线、环境与证据范围','',
        f'- 基线 HEAD：`{m["baseline"]}`，远端参考分支 `q4-diagnostic-recovery` 与用户参考提交一致。',
        '- 实验 worktree：`E:\\数模\\projects\\CUMCM2026_B_Q4_OPT`，分支 `codex/q4-stop16-cover37`。执行源码包含未提交改动，以冻结 SHA256 与 frozen_source.zip 为身份，不把基线提交冒充修改后执行提交。',
        f'- 指定引擎：`{m["simulator_root"]}`，Windows 1.2.0 / practice-gen-v1。批量调用真实 Engine；HTTP 调用该目录 start.py 的独立 32026/32027 端口。',
        f'- Python：`{m["executable"]}`；3.11.9，NumPy {m["numpy"]}；CPU，主体最多4个独立进程，压力最多2个。',
        '- 与历史三份归档计划对比，engine.py、scenario_io.py、recovered_generator.py 的 SHA256 均相同；历史 HTTP 层未提供可比指纹。仍将 A/B/C 全部重新运行，没有使用历史 830.168 秒/源作为 A 成绩。',
        '- 源位置、真实源数、类型、方向、半径与噪声种子只用于初始化及事后评价。在线动作仅来自 Solver 可见状态与合法动作反馈；两个新开关不读取场景 total。',
        '- 本轮证据标签：LOCAL_DEV / FRAMEWORK_INTEGRATION / production_eligible=false。未启动官方 App、未登录、未上传日志，正式测试 0 次。','',
        '## 实际运行计数','',
        '| 集合 | 独立物理场景 | A/B/C完整运行 | 全清 |','|---|---:|---:|---:|',
        '| 开发 | 32 | 96 | 96/96 |','| 新评估 | 128 | 384 | 384/384 |','| 单列压力 | 20 | 60 | 60/60 |',
        '| HTTP集成，复用开发场景0与1 | 0新增，2复用 | 6 | 6/6 |',
        '| 实现冒烟，复用开发场景0 | 0新增，1复用 | 3 | 3/3 |','',
        '**本轮合计 549 次完整 Solver 运行，180 个独立物理场景；其中主体 480 次，压力 60 次，HTTP 6 次，冒烟 3 次。** 2 条基线响应回放、几何边界调用和单元测试不计为完整任务运行。',
        '三组场景 JSON、噪声种子与规范化哈希在任何新评估结果出现前冻结。开发完整性通过后才启动新评估。没有按结果调整坐标、粒子、评分或门槛，没有删除失败后重跑。','',
        '## 冻结新评估128场景：完整引擎测试集合','',
        '**这一表包含 practice-gen-v1 自身生成的 12 个全定向场景，不作为严格混合源的代表性均值。** 下节把严格混合116与全定向12单列。固定128是预先冻结的宽范围引擎验收集合；不在看到结果后删案例或改变验收集合，也不称其为官方分布的独立随机样本。','',
        '| 方案 | 全清 | 均值秒/源 | P50 | P95 | P99 | 最大值 | 平均整局秒 |','|---|---:|---:|---:|---:|---:|---:|---:|']
    for v in 'ABC':
        s=e['summary'][v];q=s['per_source'];lines.append(f'| {v} | {s["full"]}/128 | {q["mean"]:.3f} | {q["P50"]:.3f} | {q["P95"]:.3f} | {q["P99"]:.3f} | {q["max"]:.3f} | {s["total_time"]["mean"]:.3f} |')
    lines+=['','A = D1+45点+原停止；B = D1+45点+16源退出；C = D1+37点+16源退出。','',
        '| 配对差（后−前） | 均值秒/源 | 相对变化 | 胜/平/负 | 最大退步秒/源 | P95变化 | P99变化 |','|---|---:|---:|---:|---:|---:|---:|']
    for a,b in (('A','B'),('B','C'),('A','C')):
        c=e['comparisons'][b+'-'+a];q=c['delta'];x=e['summary'][a]['per_source'];y=e['summary'][b]['per_source']
        lines.append(f'| {b}−{a} | {q["mean"]:.3f} | {100*q["mean"]/x["mean"]:.3f}% | {c["wins"]}/{c["ties"]}/{c["losses"]} | {max(0,q["max"]):.3f} | {y["P95"]-x["P95"]:.3f} | {y["P99"]-x["P99"]:.3f} |')
    lines+=['','P95/P99变化是各组完整任务分位数之差；CSV另保留逐例差，不能混淆两者。',
        'B 在14个16源场景触发：这些场景平均省 1545.993 秒/局（96.625 秒/源），其余114个10至15源场景完整物理动作与RNG状态完全一致。B节省的时间全部来自第16源清除后的发现扫描尾部。',
        'C−B 最大退步发生在冻结 id=67，16源，+191.570秒/源；C−A 最大退步发生在 id=119，13源，+6.686秒/源。退步案例已纳入ZIP。','',
        '例如id=67，B在访问17个发现节点后于4686.519秒完成，C访问34个节点后于7751.642秒完成；C总移动比B多约12.966公里。这说明即使静态节点更少，发现次序和D1中断重排仍可能推迟16源完成。id=119的最后源首次发现由3425.122秒推迟到7602.431秒；该指标仅辅助解释，采用判断仍以整局时间为准。','',
        '## 严格混合源与全定向场景分开报告','',
        '| 子集 | 方案 | n | 均值秒/源 | P95 | P99 |','|---|---|---:|---:|---:|---:|']
    strata={}
    for label,pred in [('严格混合源',lambda r:0<r['directional_count']<r['total']),('全定向：宽几何边界',lambda r:r['directional_count']==r['total'])]:
        strata[label]={}
        for v in 'ABC':
            q=bench.quantiles([r['mean_time_per_source'] for r in g if r['variant']==v and pred(r)]);strata[label][v]=q
            lines.append(f'| {label} | {v} | {q["n"]} | {q["mean"]:.3f} | {q["P95"]:.3f} | {q["P99"]:.3f} |')
    lines+=['','严格混合源116例中，B与C的均值及尾部分位数方向与固定128集合一致。全定向12例单列，不能据此推广至官方正式分布。','',
        '| 源数分层 | n | B−A平均秒/源 | C−B平均秒/源 | C−B最大退步 |','|---|---:|---:|---:|---:|']
    for label in ('10-15','16'):
        x=e['comparisons']['B-A']['by_count'][label];y=e['comparisons']['C-B']['by_count'][label]
        lines.append(f'| {label} | {x["n"]} | {x["mean"]:.3f} | {y["mean"]:.3f} | {max(0,y["max"]):.3f} |')
    lines+=['','按定向比例低于75%与不低于75%的完整分层见 evaluation_summary.json。','',
        '## 成本分解与失败计数','',
        '| 每局均值 | A | B | C |','|---|---:|---:|---:|']
    for field,label in [('distance','移动距离m'),('detect_count','measure次数'),('switch_count','切频次数'),('failed_clears','失败clear次数'),
        ('stage_discovery_s','发现扫描s'),('stage_active_localization_s','主动定位s'),('stage_diagnostic_s','diagnostic s'),
        ('stage_optical_fallback_s','光学兜底s'),('stage_certified_clear_s','证书/near清除s'),('runtime_s','现实Solver运行s')]:
        means=[np.mean([r[field] for r in g if r['variant']==v]) for v in 'ABC'];lines.append('| '+label+' | '+' | '.join(f'{x:.3f}' for x in means)+' |')
    ep=[r for r in pairs if r['cohort']=='evaluation']
    lines+=['','| 整局平均节省来源（前−后，秒） | 移动 | 检测 | 切频 | 失败clear成本 |','|---|---:|---:|---:|---:|']
    for c in ('B-A','C-B','C-A'):
        x=[r for r in ep if r['comparison']==c];means=[-np.mean([r[k] for r in x]) for k in ('delta_movement_s','delta_detection_s','delta_switch_s','delta_failed_clear_s')]
        lines.append('| '+c+' | '+' | '.join(f'{x:.3f}' for x in means)+' |')
    lines+=['',
        '任务未全清、运行异常、协议失败、超时均为0。新评估C有1次正常光学兜底clear未命中，随后成功全清；它是账本中的F，不是协议失败。所有MEC证书清除均未报错。',
        '逐动作独立复算使用与引擎相同的微秒舍入：移动费 round_go(1e12×hypot(dx,dy)/5000000)，再加 measure、切频或clear整数微秒。全部540条核心轨迹及6条HTTP轨迹通过。clear保持测向频道不变，无切频费。阶段为互斥记账：near/MEC清除记在certified_clear，诊断内成功清除不重复归入diagnostic时间。','',
        '## 压力与采用边界','',
        '压力20场景共60次全部全清，含16个真正混合的16源场景，以及10源边界向外/1000米、15源贴近节点/1000米、16源全向聚簇、16源全定向边界。后4种为单列的宽几何/实现压力，不混入严格混合源均值。',
        '压力集合C−B均值 −21.721秒/源，但P95由709.909升至720.161秒/源（+10.252）；P99由1047.516降至958.940。最大退步 id=171 为+204.975秒/源；其中低于75%定向比例压力子集C−B平均还会上升11.810秒/源。压力C_pass=false记录保留，它是同一统计函数在压力集合计算的结果，不是冻结新评估门槛被改写。',
        '因此推荐B为有逐例不劣支持的优化；B+C在固定新评估工程门槛通过，可作为平均收益候选。对压力尾部敏感时可继续用显式B配置。不能在在线Solver中用真实源数或真实方向比例切换策略。','',
        '## 正确性、数学证明与静态复算','',
        '- 原124项回归+新增4项停止/路径回归=128项通过；另3项HTTP客户端协议回归通过。首次原测试因稀疏worktree缺历史CSV而失败，恢复原始fixture后重跑通过，旧结果没有冒充新测试。',
        '- 指定引擎首次56项自测中1项畸形HTTP路径遇WinError10053、55项通过；未修改引擎，完整复跑56/56通过。两次状态均保留。',
        '- 6/6 HTTP完整运行：12源与16源各A/B/C，真实端口进程核验见ownership.json；核心与HTTP的位置、频道、动作、反馈、微秒时间、粒子RNG状态完全一致。HTTP原始request_id与实际enter剩余现实时间保存在wire日志。',
        '- 第16源停止使用不同频道集合，且必须accepted=true与success；重复成功不能增加集合大小，拒绝/失败/未决HTTP不计成功。所有清除路径复用clear，主循环只发一次正常user_exit。额外已观测未清track/超过16等矛盾明确报错。',
        '- 180个场景全部通过A/B前缀与N10–15完整序列验证；第16源后无measure/clear。2条A轨迹另由未修改HEAD Solver精确回放，动作、响应、粒子RNG、target trace一致。',
        '- COVERAGE37.md给出连续证明：56个700米直角等腰三角形完整铺满P；任意源沿方向平移6米，重心恒等式给出严格前向、距离[6,995.949494]米的非零顶点见证。37顶点、56面、92边、面积13720000m²已核验。',
        '- 实际引擎6336组有限位置/方向回归及0/5/1000米边界检查通过。有限回归与连续证明分别计证据。',
        '- 同一route静态复算45点31669.848481m、37点26939.696962m，差946.030304秒。完整任务收益以上述真实配对结果为准。','',
        '## 历史去重及未完成的真实边界','',
        '新种子与已读历史派生规则及三份可访问计划中676个唯一seed无重叠；未能访问历史J:原始实验目录与未归档场景，因此不能声称排除全部历史使用。当前物理场景与误差场已完整冻结，A/B/C不是只保证同seed。',
        '读取4条可访问还原引擎历史轨迹，源数均不足16，不能计算16源尾部；另3条旧合成归档16源轨迹尾部为0、1146.354、173.972秒，仅是历史反事实计算，不是指定引擎的新运行或新A成绩。完整D1历史轨迹未在当前机器可访问，现有A/B实际配对已补足实现验证。',
        '本轮未发现37点几何反例。测试集合有限，practice-gen-v1最大源半径1770米且允许全定向，并不等同题目所有1800米混合场景分布；压力样本与连续证明补充边界证据，不给整局全局最优或官方正式性能保证。','',
        '## 文件入口','',
        '- `cases.csv`：540条逐例记录；`pairs.csv`：540条配对差；frozen内另保留开发/新评估/压力CSV与分层JSON。',
        '- `frozen/core/traces/*.json.gz`：全部核心动作/反馈/RNG/阶段轨迹；`frozen/http/wire`：HTTP请求响应；`frozen/http/comparison.json`：同场景对照。',
        '- `frozen/manifest.json`、`frozen/scenes`、`frozen/frozen_source.zip`：冻结配置、源码、物理场景与指纹。',
        '- `RUN.md`：本机已经执行验证的命令；`changes.patch`：最小现有源码diff；源码与新配置另随回传ZIP附上。','']
    (root/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    bench.rb.save(root/'strata.json',strata)
    diff=subprocess.check_output(['git','diff','--','B_solver/solver.py','B_solver/geometry.py','B_solver/reporting/discovery_report.py'],cwd=BASE.parent)
    (root/'changes.patch').write_bytes(diff)
    audit=dict(baseline=m['baseline'],source_hash=bench.rb.digest(m['source_hashes']),
        completed_core=540,completed_http=6,completed_smoke=3,independent_scenarios=180,
        B_evaluation_pass=e['B_pass'],C_evaluation_pass=e['C_pass'],C_stress_statistics_pass=summaries['stress']['C_pass'],
        all_scene_hashes_verified=True,all_execution_source_hashes_unchanged=True,
        all_source_and_trace_records_present=True,formal_runs=0,default_changed=False,remote_push=False)
    bench.rb.save(root/'FINAL_AUDIT.json',audit)
    selected={0,1,17,67,119,171,179}
    bundle=root/'Q4_stop16_cover37_review.zip'
    with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED) as z:
        files=[BASE/'solver.py',BASE/'geometry.py',BASE/'reporting/discovery_report.py',BASE/'reporting/nccp_report.py',BASE/'public_max37_benchmark.py',
               BASE/'check_coverage37.py',BASE/'COVERAGE37.md',Path(__file__),BASE/'experiments/http_public_max37.py']
        files+=list((BASE/'configs').glob('q4_public_max37_*.yaml'))+list((BASE/'tests').glob('test_public_max*.py'))
        files+=list(root.glob('*.md'))+list(root.glob('*.json'))+list(root.glob('*.csv'))+list(root.glob('*.txt'))+[root/'changes.patch']
        files+=[out/'manifest.json',out/'frozen_source.zip']+list((out/'scenes').glob('*.json'))
        files+=list(out.glob('*_summary.json'))+list((out/'http').glob('*.json'))+list((out/'http/wire').glob('*.jsonl'))
        files+=list((out/'core/rows').glob('*.json'))+list((out/'http/rows').glob('*.json'))
        files+=list((out/'http/traces').glob('*.gz'))
        files+=[out/'core/traces'/f'{v}_{i:04d}.json.gz' for i in selected for v in 'ABC']
        hashes={}
        for path in sorted(set(files)):
            rel=path.relative_to(BASE).as_posix();data=path.read_bytes();z.writestr(rel,data);hashes[rel]=hashlib.sha256(data).hexdigest()
        z.writestr('BUNDLE_SHA256.json',json.dumps(hashes,indent=2))
    with zipfile.ZipFile(bundle) as z:
        assert z.testzip() is None
        hashes=json.loads(z.read('BUNDLE_SHA256.json'))
        assert all(hashlib.sha256(z.read(name)).hexdigest()==h for name,h in hashes.items())
    print(json.dumps(dict(bundle=str(bundle),size_bytes=bundle.stat().st_size,files=len(hashes),report=str(root/'REPORT.md')),ensure_ascii=False))

if __name__=='__main__':main()
