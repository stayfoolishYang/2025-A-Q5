# 2026 B题：D2扫描负担代理冻结审计包

执行核心 `dcb62ac`。本轮为D0原调度、D1距离刷新、D2扫描负担代理三方案完整配对；MEC、diagnostic v1、原频道顺序、45节点及每点全部未清频道义务固定。仅读取本地还原引擎，不启动官方App、HTTP或正式测试。

先读 `B_solver/Q4_WORKLOAD_RESULTS.md`。原始完整数表、配对差、门槛判定和图见 `experiment/final_report/`；Git中的轻量摘要镜像在 `B_solver/results/recovered/workload_20260911_summary/`。

## 计数与范围

- 新160个冻结种子：开发32×3=96次，留出128×3=384次，共480次完整新Q4运行。
- 旧discovery留出seed42、107另行重跑各3方案，共6次，单列known_counterexamples2。不能把两例旧反例称为新留出。
- 合计486次真实本地完整运行。原4条D0/D1历史轨迹仅用于与这6次中的4次精确对照，不另计新运行。
- `UNIT_TESTS.txt`是113项算法/回归测试通过记录；`REPORT_TESTS.txt`是之后新增的4项报告检查，分别记录。

## 冻结与独立复核

`PLAN.json`、`PREPARED.json`及三个manifest绑定全部种子、配置、场景与源码。三批在读取D2案例结果前同时冻结，开发及已知反例只作完整性门禁，之后不调参，留出按同一计划完整执行。

预先门槛为D2相对D1平均s/源至少下降1%，且P95、P99均不增加，完整性全通过。最后源首次发现是辅助风险指标，保留平均及最大配对延迟。若未达标，停止该D2，不继续扫权重；不据此否定所有未来的扫描负担模型。

`development_audit/`保留启动留出前的门禁原件，`final_report/`为全部完成后的复核。节点/频道义务、动作账本、MEC证书及证书多边形的真实源包含性独立审计。

D2使用D1完全相同的两条候选路线。事件保存坐标、排列、粒子数量/哈希及每频道首次命中下标直方图，足以重算移动/W/J和选择。W包含当前命中那次测量费用，同一粒子只按第一次未来signal统计，避免独立性假设。粒子只读，不传入真实源。

W是假设首个未来signal后退出扫描的代理，既非清除概率，也非真实剩余成本的严格界。未保存全部中间粒子坐标，事件算术复核不能被说成对每个中间粒子状态的完整重建。

`reference_discovery/`保留旧4条D0/D1轨迹、2个场景及旧manifest；`KNOWN_CASE_AUDIT.json`为这两个已知反例的只读拆解。当前脚本/源码保留在`B_solver/`，用户提供的三个原引擎文件在`provided_simulator/`，其SHA与冻结值一致；原始源码ZIP也保留在experiment目录。

## 解压后的只读复核

在解压目录使用含NumPy的Python运行，输出目录须尚不存在。仅重读原始证据，不启动Solver：

```text
python -B B_solver/reporting/workload_report.py --root experiment --output verification_report
```

开发门禁中的旧绝对路径按来源根映射到当前`--root`，不回退读取宿主J盘文件。包中旧路径和原来源哈希不改写。

若要重新运行某批，先把该批`manifest.json`和完整`scenes/`复制到新的空目录（不要复制rows/traces，不覆盖原件），例如`repeat_holdout/`，然后执行：

```text
python -B B_solver/recovered_benchmark.py --sim-root provided_simulator --output repeat_holdout --resume --problems 4 --device cpu --workers 4
```

该命令是真实本地运行，沿用每例1200秒现实、360000秒虚拟预算。报告不会主动执行它。完整113项原套件在Git执行提交；包内仅附本轮11项算法测试和4项报告测试，不能把局部发现范围冒充完整套件。

## 包完整性

`PACKAGE_MANIFEST.json`列出每一负载文件的字节数和SHA256。包外`.zip.sha256`及`.zip.verification.json`独立复核CRC、全部文件哈希、486对row/trace、九个分组的均值/P50/P95/P99/max以及预先门槛的最终判定。

本包只封装本轮调度实验及必要历史对照，不包含工作中的A/B论文目录。确定性设计种子不代表官方场景分布，经验分位数不提供任意场景长尾保证；本轮正式测试0次。
