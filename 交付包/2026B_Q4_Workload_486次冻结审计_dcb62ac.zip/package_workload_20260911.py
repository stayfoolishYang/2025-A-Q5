"""Package the completed D0/D1/D2 evidence, then verify the ZIP independently."""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import statistics
import zipfile

ROOT=Path('J:/2026B_experiments/workload_20260911')
REPO=Path('I:/GithubRick/2025-A-Q5')
OUT=REPO/'交付包/2026B_Q4_Workload_486次冻结审计_dcb62ac.zip'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan=json.loads((ROOT/'PLAN.json').read_bytes())
    audit=json.loads((ROOT/'final_report/AUDIT.json').read_bytes())
    assert audit['passed'] and audit['performance_conclusion_allowed'] and not OUT.exists()
    files={'experiment/'+p.relative_to(ROOT).as_posix():p.read_bytes() for p in sorted(ROOT.rglob('*')) if p.is_file()}
    source=next(ROOT.glob('frozen_source_*.zip'))
    with zipfile.ZipFile(source) as archive:
        for name,expected in plan['source_hashes'].items():
            data=archive.read(name)
            assert sha(data)==expected
            prefix,relative=name.split('/',1)
            files[('B_solver/' if prefix=='solver' else 'provided_simulator/')+relative]=data
    paths=['B_solver/STATUS.md','B_solver/Q4_WORKLOAD_PLAN.md','B_solver/Q4_WORKLOAD_RESULTS.md',
           'B_solver/Q4_DISCOVERY_RESULTS.md','B_solver/STATE_RESTORING_BRIDGE_AUDIT.md',
           'B_solver/experiments/prepare_workload.py','B_solver/reporting/workload_report.py',
           'B_solver/reporting/discovery_report.py','B_solver/reporting/nccp_report.py',
           'B_solver/tests/test_workload_discovery.py','B_solver/tests/test_workload_report.py',
           'B_solver/results/recovered/discovery_20260911_summary/evidence/PLAN.json',
           'B_solver/results/recovered/nccp_20260911_summary/evidence/PLAN.json']
    paths += ['B_solver/configs/q4_p4_diag_v1_grid_v1'+s+'.yaml' for s in ('','_refresh','_workload')]
    for name in paths:
        files[name]=(REPO/name).read_bytes()
    for path in sorted((REPO/'B_solver/results/recovered/workload_20260911_summary').rglob('*')):
        if path.is_file():
            files[path.relative_to(REPO).as_posix()]=path.read_bytes()
    files['README.md']=(ROOT/'HANDOFF.md').read_bytes()
    files['package_workload_20260911.py']=Path(__file__).read_bytes()
    manifest=dict(schema='2026B-workload-bundle-v1',new_runs=480,known_runs=6,full_runs=486,unique_new_seeds=160,
                  execution_commit=plan['git_commit'],formal_runs=0,
                  files=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in files.items()])
    with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,data in files.items():
            archive.writestr(name,data)
        archive.writestr('PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(OUT) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))==len(files)+1 and archive.testzip() is None
        for item in json.loads(archive.read('PACKAGE_MANIFEST.json'))['files']:
            p=PurePosixPath(item['path']);data=archive.read(item['path'])
            assert not p.is_absolute() and '..' not in p.parts and ':' not in str(p)
            assert len(data)==item['bytes'] and sha(data)==item['sha256']
        stored=json.loads(archive.read('experiment/final_report/AUDIT.json'))
        groups=[];total=0
        for cohort,n in (('development32',32),('holdout128',128),('known_counterexamples2',2)):
            m=json.loads(archive.read(f'experiment/{cohort}/manifest.json'))
            for mode,config in zip(('D0','D1','D2'),m['configs']['4']):
                values=[]
                for seed in range(n):
                    stem=f'experiment/{cohort}/q4/';name=f'{config["name"]}_{seed:04d}'
                    row=json.loads(archive.read(stem+'rows/'+name+'.json'))
                    trace=json.loads(gzip.decompress(archive.read(stem+'traces/'+name+'.json.gz')))
                    assert row==trace['row'] and row['run_status']=='FULL_CLEAR' and not row['error']
                    assert row['cleared']==row['total'] and row['seed']==seed and row['variant']==config['name']
                    assert row['seed_hex']==m['seeds'][seed]['seed_hex']
                    assert abs(row['virtual_time_s']/row['total']-row['mean_time_per_source'])<1e-9
                    values.append(row['mean_time_per_source']);total+=1
                s=stored['cohorts'][cohort]['summaries'][mode]['physical']
                assert abs(statistics.mean(values)-s['mean'])<1e-9 and max(values)==s['max']
                ordered=sorted(values)
                for label,q in (('P50',.5),('P95',.95),('P99',.99)):
                    x=(n-1)*q;lo=int(x);hi=min(lo+1,n-1)
                    assert abs(ordered[lo]+(ordered[hi]-ordered[lo])*(x-lo)-s[label])<1e-9
                groups.append(dict(cohort=cohort,mode=mode,runs=n,mean=statistics.mean(values)))
        assert total==486 and len(groups)==9
        a,b=[stored['cohorts']['holdout128']['summaries'][mode]['physical'] for mode in ('D1','D2')]
        threshold=(1-b['mean']/a['mean']>=.01 and b['P95']<=a['P95'] and b['P99']<=a['P99'])
        assert stored['adoption_gate']['passed']==threshold
    receipt=dict(passed=True,package=str(OUT),bytes=OUT.stat().st_size,sha256=sha(OUT.read_bytes()),
                 payload_files=len(files),matching_rows_and_traces=total,new_runs=480,known_runs=6,
                 groups=groups,adoption_threshold_met=threshold,formal_runs=0)
    OUT.with_suffix('.zip.sha256').write_text(receipt['sha256']+'  '+OUT.name+'\n',encoding='utf-8')
    OUT.with_suffix('.zip.verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False))


if __name__=='__main__':
    main()
