"""Bundle and independently verify the completed Q2 geometry evidence."""
import csv
import gzip
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import zipfile

ROOT=Path('J:/2026B_experiments/q2_score_20260911')
REPO=Path('I:/GithubRick/2025-A-Q5')
OUT=REPO/'交付包/2026B_Q2_213候选评分与卡尺审计_cfd771d.zip'
sha=lambda data:hashlib.sha256(data).hexdigest()


def main():
    assert not OUT.exists()
    files={'experiment/'+p.relative_to(ROOT).as_posix():p.read_bytes() for p in sorted(ROOT.rglob('*')) if p.is_file()}
    paths=['B_solver/Q2_SCORE_RESULTS.md','B_solver/Q2_SCORE_EXPERIMENT_PLAN.md','B_solver/STATUS.md',
           'B_solver/Q2_OPTIMIZATION_READINESS_AUDIT.md','B_solver/Q2_READONLY_SCORE_AUDIT.json',
           'B_solver/experiments/q2_score_audit.py','B_solver/reporting/q2_score_report.py',
           'B_solver/tests/test_q2_score_audit.py','B_solver/geometry.py','B_solver/questions.py',
           'B_solver/results/q2.json','B_solver/results/q2_candidates.csv']
    for name in paths:
        files[name]=(REPO/name).read_bytes()
    for p in sorted((REPO/'B_solver/results/q2_score_20260911').rglob('*')):
        if p.is_file():
            files[p.relative_to(REPO).as_posix()]=p.read_bytes()
    files['README.md']=(ROOT/'HANDOFF.md').read_bytes()
    files['package_q2_score_20260911.py']=Path(__file__).read_bytes()
    manifest=dict(schema='q2-score-bundle-v1',execution_commit='cfd771d',candidate_count=213,formal_runs=0,
                  files=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in files.items()])
    with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in files.items():
            z.writestr(name,data)
        z.writestr('PACKAGE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(OUT) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(files)+1 and z.testzip() is None
        for item in json.loads(z.read('PACKAGE_MANIFEST.json'))['files']:
            name=PurePosixPath(item['path']);data=z.read(item['path'])
            assert not name.is_absolute() and '..' not in name.parts and ':' not in str(name)
            assert len(data)==item['bytes'] and sha(data)==item['sha256']
        plan=json.loads(z.read('experiment/PLAN.json'))
        for item in plan['files']:
            assert sha(z.read('experiment/'+item['frozen']))==item['sha256']
        old=list(csv.DictReader(io.StringIO(z.read('experiment/frozen/q2_candidates.csv').decode('utf-8-sig'))))
        rows=[]
        for i in range(213):
            r=json.loads(gzip.decompress(z.read(f'experiment/candidates/{i:03d}.json.gz')))
            assert r['index']==i and r['x']==float(old[i]['x']) and r['y']==float(old[i]['y'])
            assert abs(r['baseline_diameter_m']-float(old[i]['worst_sampled_diameter_m']))<1e-7
            assert abs(r['action_time_s']-(math.hypot(r['x'],r['y'])/5+5))<1e-9
            e=r['envelope'];leaves=e['leaves']
            assert e['converged'] and e['upper_m']-e['lower_m']<=.01
            assert leaves[0][0]==0 and leaves[-1][1]==360
            assert all(a[1]==b[0] for a,b in zip(leaves,leaves[1:]))
            assert e['upper_m']==max(a[2] for a in leaves)
            rows.append(r)
        best=min(rows,key=lambda r:r['envelope']['upper_m']+.2*r['action_time_s'])
        oldbest=min(rows,key=lambda r:r['baseline_score_m'])
        assert best['index']==oldbest['index']==176
        separation=min(r['envelope']['lower_m']+.2*r['action_time_s'] for r in rows if r['index']!=176)-(best['envelope']['upper_m']+.2*best['action_time_s'])
        assert separation>0
        completed=json.loads(z.read('experiment/COMPLETED.json'))
        assert sum(r['posterior_evaluations'] for r in rows)==completed['posterior_evaluations']==834518
        assert completed['solver_runs']==completed['simulator_runs']==completed['official_calls']==0
        diagnostic=json.loads(z.read('experiment/CALIPERS_DIAGNOSTIC.json'))
        w=diagnostic['worst']
        independent=max(math.dist(a,b) for a in w['polygon'] for b in w['polygon'])
        assert abs(independent-w['stdlib_diameter_m'])<1e-10
        assert independent-w['calipers_diameter_m']>.69
        assert diagnostic['summary']['original_maxima_changed_over_1e_7']==0
    receipt=dict(passed=True,bytes=OUT.stat().st_size,sha256=sha(OUT.read_bytes()),payload_files=len(files),
                 matching_candidates=213,winner_index=176,separation_m=separation,
                 posterior_evaluations=834518,calipers_worst_independent_diameter_m=independent,formal_runs=0)
    OUT.with_suffix('.zip.sha256').write_text(receipt['sha256']+'  '+OUT.name+'\n',encoding='utf-8')
    OUT.with_suffix('.zip.verification.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(receipt))


if __name__=='__main__':
    main()
