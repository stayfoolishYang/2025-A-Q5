# Q2固定213候选评分与卡尺审计包

执行源码冻结提交cfd771d。先读B_solver/Q2_SCORE_RESULTS.md，再看experiment/report_final/RESULTS.md和全部CANDIDATES.csv。experiment/report为保留的首版报告，最终版是report_final；原始候选记录从未改写。

本轮对同一213候选核对旧15情景、连续报告角数值夹逼、粗细共同合法位置网格与near边界。旧站位仍获胜，没有候选加密、λ调参或生产策略更新。共享geometry/Q4/MEC及原始q2.json/CSV保持原样。834518是主实验后验几何计算数，不是模拟器局数；另外6390次原情景重建属于独立卡尺诊断。完整Solver、模拟器实例、官方接口及正式测试均0。

CALIPERS_DIAGNOSTIC.json保存全部104个卡尺差异及最大反例。近重复顶点会导致原旋转卡尺漏查最远对；213个候选的15情景最大值仍均未改变。新实验使用全点对距离，没有通过更改共享几何修复生产代码。

## 解压后的只读复核

在包含NumPy、Matplotlib的Python环境中，从解压目录运行：

```text
python -B B_solver/reporting/q2_score_report.py --root experiment --output independent_report
```

输出目录须尚不存在。默认只核冻结副本，不依赖PLAN中保留的旧绝对来源路径；不会重算几何或运行模拟器。--check-live-sources仅供原机器上额外核对当前原文件。

若要重复整个几何实验，应在Git提交cfd771d的工程中执行B_solver/experiments/q2_score_audit.py，使用新的--output目录和--sim-root指定提供的本地引擎目录。主脚本会记录Git版本并拒绝覆盖已有结果。保留的源码快照及SHA见experiment/frozen与PLAN.json。

VALIDATION.md说明7项预运行边界测试与实际计算计数，测试代码在B_solver/tests。包中不含任何A/B论文草稿；当前代码和结果仅作为独立审计及下一步候选搜索的基线。

PACKAGE_MANIFEST.json覆盖所有负载文件，包外SHA256及verification.json另行核对CRC、哈希、213个原记录、区间及赢家和卡尺最大反例。数值夹逼不是严格FP64证书，条件情景不是独立随机样本或官方成绩。
