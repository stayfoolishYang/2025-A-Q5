# 2026 B 题：Q4 发现调度与恢复桥审计包

执行代码冻结于 `1cf0b3d42f3d239d9e756ad3b4599c5eb55eecc8`。只使用本地还原引擎，正式测试 0 次。先读 `B_solver/Q4_DISCOVERY_RESULTS.md`，完整数表及逐案例证据在 `experiment/final_report/`。本包不含 A 题。

## 范围

- 新增 160 个预先冻结种子，每种子 4 个方案：开发 32×4=128 次，留出 128×4=512 次，共 640 次完整 Q4 运行。两批分别统计，没有据开发结果调参。
- 4 个方案均使用 MEC。只比较原调度、定位后刷新剩余节点、未知频道优先、两者组合。全部 45 个原保证节点和每点全部未清频道的扫描义务保留。
- 旧 519 种子的发现成本审计仅为策略设计依据，不计为新增运行。NCCP/segment/Gap 历史结果只作为负结果和边界结论引用，本包没有重跑它们。
- 恢复桥审计为 STOP，没有新增桥接代码、参数或运行。

## 文件

`experiment/PLAN.json`、`PREPARED.json` 与两批 `manifest.json` 绑定种子、配置、场景、源码。`development32/`、`holdout128/` 含全部原始 scene、row、trace、运行回执和验收；各 trace 内嵌 row，与独立 row 严格相等。

`development_audit/` 是启动留出前的完整性门禁原件。`final_report/` 是后续完整复核，含首次发现的独立配对退步指标；开发和最终报告脚本的哈希均保留。最终图仅展示 128 例留出，不合并开发案例。

`CONSTRAINTS_AUDIT.json` 是代码边界审计；`UNIT_TESTS.txt` 为 102 项测试通过记录。`BASELINE_AUDIT.json` 为旧 519 例只读审计。证书检查包括存储多边形内真实源包含性和提交站位的 FP64/精确有理数复核，不声称已逐一重建所有中间观测后的硬域。

`B_solver/` 的执行模块来自冻结源码快照；报告、文档、配置及新测试另行随包。`provided_simulator/` 为用户提供的三个原始引擎文件，SHA 与实验冻结值一致。原封不动的嵌套 `experiment/frozen_source_1cf0b3d.zip` 也保留。

`PACKAGE_MANIFEST.json` 对每个负载文件记录字节数和 SHA256。包外 `.zip.sha256` 与 `.zip.verification.json` 记录 ZIP 完整性、640 组 row/trace 以及八个分组均值/分位数的独立复算结果。

## 只读复核

在解压目录，以含 NumPy 的 Python 运行下列命令，输出必须是一个尚不存在的新目录；不会启动模拟器。历史绝对路径仅为来源标记，报告会根据 `--root` 解析包内证据。

```text
python -B B_solver/reporting/discovery_report.py --root experiment --output verification_report
python -B B_solver/reporting/plot_discovery.py verification_report
```

如需重新运行算法，应先将某批的 `manifest.json` 和完整 `scenes/` 复制到新的空目录，如 `repeat_holdout/`；不要复制 `rows/`、`traces/` 或覆盖已有证据。然后在同一解压目录执行：

```text
python -B B_solver/recovered_benchmark.py --sim-root provided_simulator --output repeat_holdout --resume --problems 4 --device cpu --workers 4
```

此命令会真实运行该批全部 4 个冻结配置，而非演练官方程序。单一场景的 1200 s 现实预算和 360000 s 虚拟预算沿用原设置。包中只包含本轮新增 7 项调度测试的文件，完整 102 项测试代码在对应 Git 提交，不能把包内单项测试发现范围冒充完整套件。

本地设计种子不代表官方分布；经验分位数不保证任意场景长尾。剩余开路径变短也不意味着重调度后的整局逐例不劣，退步案例必须与均值一同读取。
