"""Read saved Q4 traces for extreme paired cases; no Solver/Engine calls."""
import csv
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('J:/2026B_experiments/discovery_20260911')


def main():
    report = ROOT/'final_report'
    assert json.loads((report/'AUDIT.json').read_bytes())['passed']
    with (report/'PAIRS.csv').open(encoding='utf-8-sig',newline='') as stream:
        pairs = [p for p in csv.DictReader(stream) if p['cohort']=='holdout128'
                 and p['route_refresh']=='1' and p['unknown_first']=='0']
    assert len(pairs)==128 and all(p['valid_pair']=='True' for p in pairs)
    selections = {
        'largest_total_regression':max(pairs,key=lambda p:float(p['mean_time_per_source_delta'])),
        'largest_last_discovery_delay':max(pairs,key=lambda p:float(p['last_source_first_seen_s_delta'])),
        'largest_total_gain':min(pairs,key=lambda p:float(p['mean_time_per_source_delta']))}
    cases = {}
    for label,pair in selections.items():
        seed=int(pair['seed'])
        if seed in cases:
            cases[seed]['selected_for'].append(label)
            continue
        traces = []
        for suffix in ('','_refresh','_unknown','_refresh_unknown'):
            path=ROOT/'holdout128/q4/traces'/f'P4_diagnostic_v1_grid_v1{suffix}_{seed:04d}.json.gz'
            traces.append((path,json.loads(gzip.decompress(path.read_bytes()))))
        base,candidate = traces[0][1],traces[1][1]
        signature=lambda a:(a['path'],a.get('position'),a.get('channel'))
        divergence=next(i for i,(a,b) in enumerate(zip(base['actions'],candidate['actions'])) if signature(a)!=signature(b))
        summaries=[]
        for path,trace in traces:
            seen={}
            for i,action in enumerate(trace['actions']):
                if action['path']=='/measure' and action['response']['measure_result'] in ('direction','near'):
                    seen.setdefault(action['channel'],dict(action_index=i,time_s=action['response']['virtual_time_s'],position=action['position']))
            last=max(seen,key=lambda c:seen[c]['time_s'])
            assert len(seen)==trace['row']['total']
            summaries.append(dict(variant=trace['row']['variant'],row=trace['row'],stages=trace['stages'],
                trace_path=str(path),trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                last_source=dict(channel=last,**seen[last]),
                target_times=[dict(channel=t['channel'],first_seen=t['first_seen_time'],clear_time=t['clear_time']) for t in trace['targets']]))
        cases[seed]=dict(seed=seed,derivation_index=seed+32,seed_hex=pair['seed_hex'],selected_for=[label],
            total_delta_s_per_source=float(pair['mean_time_per_source_delta']),
            last_discovery_delta_s=float(pair['last_source_first_seen_s_delta']),
            first_divergence_action_index=divergence,last_shared_action=base['actions'][divergence-1],
            baseline_next=base['actions'][divergence],refresh_next=candidate['actions'][divergence],variants=summaries)
    result=dict(scope='Read-only extreme-case diagnosis, selection is post hoc; not new independent runs.',
                formal_runs=0,solver_runs=0,cohort='holdout128',cases=list(cases.values()))
    out=report/'CASE_AUDIT.json'
    with out.open('x',encoding='utf-8') as stream:
        json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False)
    print(json.dumps([{k:v for k,v in c.items() if k not in ('variants','last_shared_action','baseline_next','refresh_next')} for c in cases.values()]))


if __name__=='__main__':
    main()
