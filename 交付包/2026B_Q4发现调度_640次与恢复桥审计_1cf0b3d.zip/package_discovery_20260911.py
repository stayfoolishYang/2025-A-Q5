"""Package this completed B-only experiment and independently verify its ZIP."""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import statistics
import zipfile

ROOT = Path('J:/2026B_experiments/discovery_20260911')
REPO = Path('I:/GithubRick/2025-A-Q5')
OUT = REPO/'交付包/2026B_Q4发现调度_640次与恢复桥审计_1cf0b3d.zip'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    plan = json.loads((ROOT/'PLAN.json').read_bytes())
    audit = json.loads((ROOT/'final_report/AUDIT.json').read_bytes())
    assert audit['passed'] and audit['performance_conclusion_allowed']
    assert not OUT.exists()
    files = {('experiment/'+p.relative_to(ROOT).as_posix()):p.read_bytes()
             for p in sorted(ROOT.rglob('*')) if p.is_file()}
    with zipfile.ZipFile(ROOT/'frozen_source_1cf0b3d.zip') as source:
        for name, expected in plan['source_hashes'].items():
            data = source.read(name)
            assert digest(data) == expected
            prefix, relative = name.split('/', 1)
            files[('B_solver/' if prefix == 'solver' else 'provided_simulator/')+relative] = data
    paths = ['B_solver/STATUS.md', 'B_solver/Q4_DISCOVERY_RESULTS.md',
             'B_solver/Q4_DISCOVERY_PLAN.md', 'B_solver/Q4_DISCOVERY_BASELINE_AUDIT.md',
             'B_solver/STATE_RESTORING_BRIDGE_AUDIT.md',
             'B_solver/NCCP_RESULTS.md', 'B_solver/CLEARANCE_SHADOW_AUDIT.md',
             'B_solver/experiments/prepare_discovery.py',
             'B_solver/reporting/discovery_report.py', 'B_solver/reporting/nccp_report.py',
             'B_solver/reporting/plot_discovery.py', 'B_solver/tests/test_discovery_scheduling.py']
    paths += [('B_solver/configs/q4_p4_diag_v1_grid_v1'+s+'.yaml')
              for s in ('', '_refresh', '_unknown', '_refresh_unknown')]
    for name in paths:
        assert name not in files
        files[name] = (REPO/name).read_bytes()
    for path in sorted((REPO/'B_solver/results/recovered/discovery_20260911_summary').rglob('*')):
        if path.is_file():
            files[path.relative_to(REPO).as_posix()] = path.read_bytes()
    files['package_discovery_20260911.py'] = Path(__file__).read_bytes()
    files['audit_discovery_cases_20260911.py'] = (ROOT.parent/'audit_discovery_cases_20260911.py').read_bytes()
    files['README.md'] = (ROOT/'HANDOFF.md').read_bytes()
    manifest = dict(schema='2026B-discovery-bundle-v1', full_runs=640, unique_seeds=160,
                    development_runs=128, holdout_runs=512, formal_runs=0,
                    execution_commit=plan['git_commit'],
                    files=[dict(path=n, bytes=len(b), sha256=digest(b)) for n,b in files.items()])
    with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in files.items():
            archive.writestr(name, data)
        archive.writestr('PACKAGE_MANIFEST.json', json.dumps(manifest,ensure_ascii=False,indent=2))
    # Re-open only the ZIP; verify hashes, all paired rows/traces, counts and eight group summaries.
    with zipfile.ZipFile(OUT) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == len(files)+1
        assert archive.testzip() is None
        stored = json.loads(archive.read('PACKAGE_MANIFEST.json'))
        for item in stored['files']:
            p = PurePosixPath(item['path'])
            assert not p.is_absolute() and '..' not in p.parts and ':' not in str(p)
            data = archive.read(item['path'])
            assert len(data) == item['bytes'] and digest(data) == item['sha256']
        stored_audit = json.loads(archive.read('experiment/final_report/AUDIT.json'))
        groups, row_count, trace_count = [], 0, 0
        for cohort,n in (('development32',32),('holdout128',128)):
            manifest_data = json.loads(archive.read(f'experiment/{cohort}/manifest.json'))
            for config in manifest_data['configs']['4']:
                values = []
                for seed in range(n):
                    stem = f'experiment/{cohort}/q4/'
                    name = config['name']+f'_{seed:04d}'
                    row = json.loads(archive.read(stem+'rows/'+name+'.json'))
                    trace = json.loads(gzip.decompress(archive.read(stem+'traces/'+name+'.json.gz')))
                    assert row == trace['row'] and row['run_status'] == 'FULL_CLEAR'
                    assert row['cleared'] == row['total'] and not row['error']
                    assert row['seed'] == seed and row['variant'] == config['name']
                    assert row['seed_hex'] == manifest_data['seeds'][seed]['seed_hex']
                    assert abs(row['virtual_time_s']/row['total']-row['mean_time_per_source']) < 1e-9
                    values.append(row['mean_time_per_source'])
                    row_count += 1
                    trace_count += 1
                summary = stored_audit['cohorts'][cohort]['summaries'][config['name']]['physical']
                assert abs(statistics.mean(values)-summary['mean']) < 1e-9
                assert max(values) == summary['max']
                ordered = sorted(values)
                for label, q in (('P50',.5),('P95',.95),('P99',.99)):
                    pos=(n-1)*q; lo=int(pos); hi=min(lo+1,n-1)
                    value=ordered[lo]+(ordered[hi]-ordered[lo])*(pos-lo)
                    assert abs(value-summary[label]) < 1e-9
                groups.append(dict(cohort=cohort,variant=config['name'],runs=n,mean=statistics.mean(values)))
        assert row_count == trace_count == 640 and len(groups) == 8
    verification = dict(passed=True, package=str(OUT), bytes=OUT.stat().st_size,
                        sha256=digest(OUT.read_bytes()), payload_files=len(files),
                        full_rows=row_count, matching_traces=trace_count, groups=groups, formal_runs=0)
    OUT.with_suffix('.zip.sha256').write_text(verification['sha256']+'  '+OUT.name+'\n',encoding='utf-8')
    OUT.with_suffix('.zip.verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(verification,ensure_ascii=False))


if __name__ == '__main__':
    main()
